local codeStr, threadObj = ...
local betterDLL = require("betterDLL")

local function checkArg(n, have, ...)
	have = type(have)
	local tbl = {...}
	for _, t in ipairs(tbl) do
		if have == t then
			return
		end
	end
	error(string.format("bad argument #%d (%s expected, got %s)", n, table.concat(tbl, " or "), have), 3)
end

_BETTERAPI_UNSAFE_GLOBAL_ENV = true

local function fast()
    local optimizations = {
        "fold",
        "cse",
        "dce",
        "narrow",
        "loop",
        "fwd",
        "dse",
        "abc",
        "sink",
        "fuse",
        "fma",
        "hotloop=2",
        "hotexit=2",
        "maxmcode=131072",
        "sizemcode=128",
        "maxtrace=8096",
        "maxrecord=8096",
        "maxirconst=8096",
        "maxside=8096",
        "maxsnap=8096",
        "tryside=32",
        "instunroll=16",
        "loopunroll=60"
    }
    jit.opt.start(2)
    jit.opt.start(unpack(optimizations))
    --collectgarbage("setpause", 1000)
    --collectgarbage("setstepmul", 105)
end

local env
env = {
    _VERSION = _VERSION,

	type = type,
	assert = assert,
	error = error,
	ipairs = ipairs,
	next = next,
	pairs = pairs,
	pcall = pcall,
	select = select,
	tonumber = tonumber,
	tostring = tostring,
	unpack = unpack,
	xpcall = xpcall,

	setmetatable = setmetatable,
	getmetatable = getmetatable,

    loadstring = function (chunk, chunkname, env)
        checkArg(1, chunk, "string")
        checkArg(2, chunkname, "string", "nil")
        checkArg(3, env, "table")
        chunk = chunk or ""
        env = env or {}

        -- preventing bytecode loading
        if chunk:byte(1) == 27 then
            return nil, "binary bytecode prohibited"
        end

        -- checking for loading to the global environment (additional precautions)
        local code = load("return _G", chunkname, "t", env)
        local v1, v2 = pcall(code)
        if not v1 or v2 == _G then
            return nil, "load to the global environment is not possible"
        end

        -- if this variable exists in the code loaded with the same arguments, it means that it is somehow loaded into the global environment (need to prevent this)
        code = load("return _BETTERAPI_UNSAFE_GLOBAL_ENV", chunkname, "t", env)
        local v1, v2 = pcall(code)
        if not v1 or v2 then
            return nil, "load to the global environment is not possible"
        end

        -- loading the code
        return load(chunk, chunkname, "t", env)
    end,

	threadTunnelSet = function(index, value)
		checkArg(1, index, "number")
		checkArg(2, value, "string", "number", "boolean", "nil")
		thread_set(threadObj, index, value)
	end,
	threadTunnelGet = function(index)
		checkArg(1, index, "number")
		return thread_get(threadObj, index)
	end,
	sleep = function(time)
		checkArg(1, time, "number")
		thread_sleep(time)
	end,
	fast = fast,
	
    coroutine = coroutine,
	string = string,
	table = table,
	math = math,
	bit = bit,
	os = {
		clock = os.clock,
		difftime = os.difftime,
		time = os.time,
		date = os.date
	},

    better = {
        fast = fast,
        algorithm = {
            base64_encode = betterDLL.base64_encode,
            base64_decode = betterDLL.base64_decode,
            sha256_text = betterDLL.sha256_text,
            sha256_binary = betterDLL.sha256_binary
        }
    }
}

env._G = env

assert(env.loadstring(codeStr, nil, env))()