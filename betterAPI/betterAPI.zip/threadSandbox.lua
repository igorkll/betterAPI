local codeStr, threadObj = ...
local betterDLL = require("betterDLL")
dofile("json.lua")

threadData = json.decode(threadData)

function print(...)
    local tbl = {...}
    for i, v in ipairs(tbl) do
        tbl[i] = tostring(v)
    end

    local file = io.open("BetterTemp/threadLog.log", "a")
    if file then
        file:write(table.concat(tbl, "  ") .. "\n")
        file:close()
    end
end

local function betterTitle(title)
    print("-------- " .. title .. " --------")
end

local function rawReadFile(path)
    local file, err = io.open(path, "rb")
    if not file then return nil, tostring(err or "unknown error") end
    local content = file:read("*a")
    file:close()
    return tostring(content)
end

local function checkArg(n, have, ...)
    have = type(have)
    local tbl = {...}
    for _, t in ipairs(tbl) do
        if have == t then
            return
        end
    end
    error(string.format("bad argument #%d (%s expected, got %s)", n, table.concat(tbl, " or "), have), 3)
end

_BETTERAPI_UNSAFE_GLOBAL_ENV = true

local function fast()
    local optimizations = {
        "fold",
        "cse",
        "dce",
        "narrow",
        "loop",
        "fwd",
        "dse",
        "abc",
        "sink",
        "fuse",
        "fma",
        "hotloop=2",
        "hotexit=2",
        "maxmcode=131072",
        "sizemcode=128",
        "maxtrace=8096",
        "maxrecord=8096",
        "maxirconst=8096",
        "maxside=8096",
        "maxsnap=8096",
        "tryside=32",
        "instunroll=16",
        "loopunroll=60"
    }
    jit.opt.start(2)
    jit.opt.start(unpack(optimizations))
    --collectgarbage("setpause", 1000)
    --collectgarbage("setstepmul", 105)
end

local function ipairsEx(...)
    local tables = {...}
    local tbl = {}
    for _, ltbl in ipairs(tables) do
        for _, v in ipairs(ltbl) do
            table.insert(tbl, v)
        end
    end

    return ipairs(tbl)
end

local cacheModWhitelist = {}
local function isModInWhilelist(modsLists)
    local trace = debug.traceback()

    if cacheModWhitelist[trace] then
        return cacheModWhitelist[trace][1], cacheModWhitelist[trace][2]
    end

    local description = threadData.description
    for _, mod in ipairsEx(unpack(modsLists)) do
        print("comparison with", mod)
        local ok = true
        for k, v in pairs(mod) do
            if k ~= "apis" and description[k] ~= v then
                print("bad parameter", k, "need", description[k], "there is", v)
                ok = false
                break
            end
        end
        if ok then
            print("(betterAPI) -------- the mod was successfully FOUND in the whitelist: ", description.name)
            cacheModWhitelist[trace] = {true, mod.apis}
            return true, mod.apis
        end
    end

    cacheModWhitelist[trace] = {false}
    return false
end

local function getSelfModName()
    return threadData.description.name
end

local function modCheckRaw(modsLists, ...)
    local requiredAPIcategory = {...}
    local allowed, apis = isModInWhilelist(modsLists)
    if not allowed then
        error("(" .. getSelfModName() .. ") your mod does not have permission to use betterAPI from bananapen. contact bananapen for permission to use betterAPI. if you are trying to use the API from an extension, then you probably need to contact the extension developer to gain access.")
    end
    if apis then
        for _, requiredAPI in ipairs(requiredAPIcategory) do
            local finded = false
            for i, v in ipairs(apis) do
                if v == requiredAPI then
                    finded = true
                    break
                end
            end
            if not finded then
                error("(" .. getSelfModName() .. ") you don't have access to " .. requiredAPI .. " in betterAPI or extension")
            end
        end
    end
end

local function modCheckCEx(mods, ...)
    modCheckRaw({mods}, ...)
end

local function modCheckEx(mods, ...)
    modCheckRaw({threadData.modsWhitelist, mods}, ...)
end

local function modCheck(...)
    modCheckRaw({threadData.modsWhitelist}, ...)
end

local exitHandlers = {}

_G.bext = {
    checkArg = checkArg,
    loadDLL = betterDLL.loadDLL,
    modCheckCEx = modCheckCEx,
    modCheckEx = modCheckEx,
    modCheck = modCheck,
    registerHandler_exit = function(func)
        exitHandlers[func] = true
    end,
    isThread = true
}

local function runHandlers(handlers)
    local handlersCount = 0
    for handler in pairs(handlers) do
        handler()
        handlersCount = handlersCount + 1
    end
    return handlersCount
end

function _threadKill()
    print("calling exit handlers (thread)...")
    print("exit handlers called! (" .. runHandlers(exitHandlers) .. ")")
end

local better = {
    fast = fast,
    algorithm = {
        base64_encode = betterDLL.base64_encode,
        base64_decode = betterDLL.base64_decode,
        sha256_text = betterDLL.sha256_text,
        sha256_binary = betterDLL.sha256_binary
    }
}

local function addPackageFolder(folder)
    package.path = package.path .. ";.\\" .. folder .. "\\?.lua"
    package.cpath = package.cpath .. ";.\\" .. folder .. "\\?.dll"
end

local function loadLuaExtension(path, ...)
    print("loadLuaExtension...", "  ("  .. path .. ")")

    local func, err = loadfile(path)
    if func then
        print("loadLuaExtension result: ", xpcall(func, debug.traceback, better, ...))
    else
        print("loadLuaExtension err: ", err)
    end
end

local threadExtensions = rawReadFile("BetterTemp/threadExtensions.json")
if threadExtensions then
    threadExtensions = json.decode(threadExtensions)
end
if threadExtensions and #threadExtensions > 0 then
    betterTitle("loading extensions (thread)")

    for _, threadExtension in ipairs(threadExtensions) do
        addPackageFolder(threadExtension[3])
        loadLuaExtension(threadExtension[1], threadExtension[2])
    end
end

local env
env = {
    _VERSION = _VERSION,

    print = print,
    type = type,
    assert = assert,
    error = error,
    ipairs = ipairs,
    next = next,
    pairs = pairs,
    pcall = pcall,
    select = select,
    tonumber = tonumber,
    tostring = tostring,
    unpack = unpack,
    xpcall = xpcall,

    setmetatable = setmetatable,
    getmetatable = getmetatable,

    loadstring = function (chunk, chunkname, env)
        checkArg(1, chunk, "string")
        checkArg(2, chunkname, "string", "nil")
        checkArg(3, env, "table")
        chunk = chunk or ""
        env = env or {}

        -- preventing bytecode loading
        if chunk:byte(1) == 27 then
            return nil, "binary bytecode prohibited"
        end

        -- checking for loading to the global environment (additional precautions)
        local code = load("return _G", chunkname, "t", env)
        local v1, v2 = pcall(code)
        if not v1 or v2 == _G then
            return nil, "load to the global environment is not possible"
        end

        -- if this variable exists in the code loaded with the same arguments, it means that it is somehow loaded into the global environment (need to prevent this)
        code = load("return _BETTERAPI_UNSAFE_GLOBAL_ENV", chunkname, "t", env)
        local v1, v2 = pcall(code)
        if not v1 or v2 then
            return nil, "load to the global environment is not possible"
        end

        -- loading the code
        return load(chunk, chunkname, "t", env)
    end,

    threadTunnelSet = function(index, value)
        checkArg(1, index, "number")
        checkArg(2, value, "string", "number", "boolean", "nil")
        thread_set(threadObj, index, value)
    end,
    threadTunnelGet = function(index)
        checkArg(1, index, "number")
        return thread_get(threadObj, index)
    end,
    sleep = function(time)
        checkArg(1, time, "number")
        thread_sleep(time)
    end,
    fast = fast,
    
    coroutine = coroutine,
    string = string,
    table = table,
    math = math,
    bit = bit,
    os = {
        clock = os.clock,
        difftime = os.difftime,
        time = os.time,
        date = os.date
    },

    better = better
}

env._G = env

assert(env.loadstring(codeStr, nil, env))()