print("> forceControl.lua")
local ffi = require("ffi")

ffi.cdef[[
bool AllocConsole();
typedef void* HWND;
HWND GetConsoleWindow();
int ShowWindow(HWND hWnd, int nCmdShow);
]]

--[[
if not ffi.C.GetConsoleWindow() then
	ffi.C.AllocConsole()
	local consoleWindow = ffi.C.GetConsoleWindow()
	ffi.C.ShowWindow(consoleWindow, 0)
end
]]

ffi.C.AllocConsole()

local currentVersion = ...

function betterConsoleSplash()
    os.execute("echo ------                                  betterAPI console has been created                             ------")
    os.execute("echo ------                      there may be several of these consoles (this is normal)                    ------")
    os.execute("echo ------         DO NOT CLOSE THIS WINDOW UNDER ANY CIRCUMSTANCES. OTHERWISE, THE GAME WILL CLOSE        ------")
    os.execute("echo ------                      THE INFORMATION HERE MAY SEEM LIKE A BUG, ALTHOUGH IT IS NOT               ------")
    os.execute("echo ------ IF YOU SEE A MESSAGE ABOUT MISSING FILES HERE, JUST IGNORE IT. THAT'S HOW IT'S MEANT TO BE!!!!  ------")
    os.execute("echo ------                       just ignore this window, if you see it then minimize it                   ------")
    os.execute("echo ------------------------ betterAPI info")
    os.execute("echo betterAPI version: " .. tostring(currentVersion or "unknown"))
    os.execute("echo ------------------------")
end

betterConsoleSplash()