local debugMode = false
local disableCoroutineFix = true
local forceUpdate = false

--------------------------------------------------- cache api

local sm = unsafe_env.sm

local json_open = sm.json.open
local json_save = sm.json.save
local game_getCurrentTick = sm.game.getCurrentTick
local json_parseJsonString = sm.json.parseJsonString
local uuid_new = sm.uuid.new
local coroutine_running = coroutine.running

--------------------------------------------------- variables

local better, betterShadow

local bellChar = string.char(7)
local nullUuid = "00000000-0000-0000-0000-000000000000"
local fileReadonly = "betterAPI does not allow overwriting this file"

local audioScripts = {}
local registeredContents = {}
local threadList = {}
local exitHandlers = {}
local tickHandlers = {}

local AUDIO_TYPE_NONE = -1
local AUDIO_TYPE_URL = 0
local AUDIO_TYPE_FILE = 1
local AUDIO_TYPE_PCM = 2
local AUDIO_TYPE_RAM = 3

--------------------------------------------------- init

local betterDLL = require("betterDLL")
betterDLL.init()

--------------------------------------------------- test

--[[
do
    local source = "hello, world!"
    local encoded = betterDLL.base64_encode(source)
    print("base64 test: ", source, encoded, betterDLL.base64_decode(encoded))

    print("sha256_text test: ", betterDLL.sha256_text(source))
    print("sha256_binary test: ", betterDLL.sha256_binary(source))
    print("sha256_file_text test: ", betterDLL.sha256_file_text("forceConsole.lua"))
    print("sha256_file_binary test: ", betterDLL.base64_encode(betterDLL.sha256_file_binary("forceConsole.lua")))
    print("sha256_file_text test: ", betterDLL.sha256_file_text("bass.dll"))
    print("sha256_file_binary test: ", betterDLL.base64_encode(betterDLL.sha256_file_binary("bass.dll")))
end
]]

---------------------------------------------------

local function rawReadFile(path)
    local file, err = io.open(path, "rb")
    if not file then return nil, tostring(err or "unknown error") end
    local content = file:read("*a")
    file:close()
    return tostring(content)
end

local versionFileName = "betterVersion.txt"
local currentVersion = rawReadFile(versionFileName)

local function addPackageFolder(folder)
    package.path = package.path .. ";.\\" .. folder .. "\\?.lua"
    package.cpath = package.cpath .. ";.\\" .. folder .. "\\?.dll"
end

addPackageFolder("python")

_BETTERAPI_UNSAFE_GLOBAL_ENV = true --for additional verification in loadstring
assert(loadfile("forceConsole.lua"))(currentVersion)

local function runHandlers(handlers)
    local handlersCount = 0
    for handler in pairs(handlers) do
        handler()
        handlersCount = handlersCount + 1
    end
    return handlersCount
end

local function betterTitle(title)
    print("-------- " .. title .. " --------")
end

local python = require("python")

local function audioFree(audioScript)
    if audioScript.isStream then
        if audioScript.pcmstream and audioScripts[audioScript.pcmstream] then
            audioScript.pcmstream:destroy()
        end
    
        for audio in pairs(audioScript.destroyAudio) do
            if audioScripts[audio] then
                audio:destroy()
            end
        end

        audioScripts[audioScript.object] = nil
        return
    end

    betterDLL.audio_free(audioScript.handle)
    if audioScript.deleteAfterDestroy then
        audioScript.ownerCounter.ownerCounter = audioScript.ownerCounter.ownerCounter - 1
        if audioScript.ownerCounter.ownerCounter <= 0 then
            betterDLL.filesystem_asyncRemove(audioScript.path)
        end
    end

    audioScripts[audioScript.object] = nil
end

__g_proxy__ = newproxy( true )
local mt = getmetatable( __g_proxy__ )
mt.__gc = function( self )
	print("calling exit handlers...")
    print("exit handlers called! (" .. runHandlers(exitHandlers) .. ")")
    
    print("killing threads...")
    local threadCount = 0
    for _, thread in pairs(threadList) do
        betterDLL.thread_kill(thread)
        threadCount = threadCount + 1
    end
    threadList = {}
    print("threads killed! (" .. threadCount .. ")")

    print("stopping audio...")
    local audioCount = 0
    for _, audioScript in pairs(audioScripts) do
        audioFree(audioScript)
        audioCount = audioCount + 1
    end
    print("audio stopped! (" .. audioCount .. ")")

    --[[
    print("betterDLL.unloadDLLs...")
    betterDLL.unloadDLLs()
    print("betterDLL.unloadDLLs called")
    ]]
    
    print("calling _release_better...")
    _release_better()
    print("_release_better called")

    print("calling betterDLL.stop...")
    betterDLL.stop()
    print("betterDLL.stop called")
end

--------------------------------------------------- get paths

local workshopFolder
local tryFindWorkshop = 0
local function tryWorkshop(path)
    if workshopFolder then return end
    tryFindWorkshop = tryFindWorkshop + 1
    print("attempt to search for a workshop: ", path, " (" .. tryFindWorkshop .. ")")
    if betterDLL.filesystem_exists(path) then
        workshopFolder = path
        print("workshop finded!")
    end
end

tryWorkshop("../../../workshop/content/387990/")
local checkDisks = {"C", "D", "E", "F"}
for char = string.byte("A"), string.byte("Z") do
    table.insert(checkDisks, string.char(char))
end
for _, chr in ipairs(checkDisks) do
    tryWorkshop(chr .. ":\\Program Files (x86)\\Steam\\steamapps\\workshop\\content\\387990\\")
    tryWorkshop(chr .. ":\\Program Files\\Steam\\steamapps\\workshop\\content\\387990\\")
    tryWorkshop(chr .. ":\\Steam\\steamapps\\workshop\\content\\387990\\")
end

if not workshopFolder then
    io.write("THE WORKSHOP FOLDER WAS NOT FOUND!!!\n")
    error("THE WORKSHOP FOLDER WAS NOT FOUND!!!")
end

local steamID = betterDLL.getSteamID()
local selfWorkshopFolder = workshopFolder .. "3177944610/"
local selfWorkshopContentFolder = selfWorkshopFolder .. "content/"
local localFolder, localModsFolder, localBlueprintsFolder, betterFsFolder
if steamID then
    localFolder = os.getenv("APPDATA") .. "/Axolot Games/Scrap Mechanic/User/User_" .. steamID .. "/"
    localModsFolder = localFolder .. "Mods/"
    localBlueprintsFolder = localFolder .. "Blueprints/"
    betterFsFolder = localFolder .. "BetterFS/"
end

local workingDirectory = io.popen("cd"):read("*l")
if workingDirectory:sub(#workingDirectory, #workingDirectory) == "/" then
    workingDirectory = workingDirectory:sub(1, #workingDirectory - 1)
end

local gameExeFolderName = "Release"
local gameRootFolder = workingDirectory:sub(1, #workingDirectory - #gameExeFolderName - 1)
local betterCacheLocalPath = "BetterCache"
local betterTempLocalPath = "BetterTemp"
local betterTempDataLocalPath = "../Data/BetterTempData"
local betterCacheGlobalPath = workingDirectory .. "\\" .. betterCacheLocalPath
local betterTempGlobalPath = workingDirectory .. "\\" .. betterTempLocalPath
local gameSettingsPath = localFolder and (localFolder .. "settings.json")
local unpackedExtensionsLocalPath = betterCacheLocalPath .. "/ext"
local unpackedExtensionsGlobalPath = betterCacheGlobalPath .. "/ext"

betterTitle("betterAPI paths")
print("betterCacheGlobalPath", betterCacheGlobalPath)
print("betterTempGlobalPath", betterTempGlobalPath)
print("gameRootFolder", gameRootFolder)
print("workingDirectory", workingDirectory)
print("selfWorkshopFolder", selfWorkshopFolder)
print("selfWorkshopContentFolder", selfWorkshopContentFolder)
print("localFolder", localFolder)
print("localModsFolder", localModsFolder)
print("localBlueprintsFolder", localBlueprintsFolder)
print("betterFsFolder", betterFsFolder)
print("workshopFolder", workshopFolder)
print("gameSettingsPath", gameSettingsPath)
print("unpackedExtensionsLocalPath", unpackedExtensionsLocalPath)
print("unpackedExtensionsGlobalPath", unpackedExtensionsGlobalPath)

--------------------------------------------------- initializing the environment

local function recreateDirectory(path)
    print("recreateDirectory", path)
    betterDLL.filesystem_remove(path)
    betterDLL.filesystem_mkdir(path)
end

local function createDirectoryOnce(path)
    print("createDirectoryOnce", path)
    if not betterDLL.filesystem_exists(path) then
        betterDLL.filesystem_mkdir(path)
    end
end

local function clearTemp()
    recreateDirectory(betterTempLocalPath)
    recreateDirectory(betterTempDataLocalPath)
end

betterTitle("betterAPI init folders")
clearTemp()
recreateDirectory(betterTempLocalPath .. "/tts")
createDirectoryOnce(betterCacheLocalPath)
createDirectoryOnce(betterCacheLocalPath .. "/tts")
createDirectoryOnce(unpackedExtensionsLocalPath)
createDirectoryOnce(betterFsFolder)

--------------------------------------------------- functions

local extensionDynamicload

local function holeLen(tbl)
    local max = 0
    for k, v in pairs(tbl) do
        max = math.max(max, k)
    end
    return max
end

local function map(value, low, high, low_2, high_2)
    return low_2 + (high_2 - low_2) * ((value - low) / (high - low))
end

local function round(value)
    return math.floor(value + 0.5)
end

local function mapRound(value, low, high, low_2, high_2)
    return round(map(value, low, high, low_2, high_2))
end

local function randomName()
    return tostring(uuid_new())
end

local function randomStr(len)
    local str = ""
    for i = 1, len or 16 do
        str = str .. tostring(math.random(0, 9))
    end
    return str
end

local function vbsExec(script)
    --return [[cmd /T:1F /K ^"cscript.exe //nologo //B "]] .. script .. [[" "%~1"^&&exit^"]]
    --return [[wscript.exe "invisible.vbs" "]] .. script .. '"'
    --return "nircmd.exe exec hide \"cscript " .. script .. "\""
    return "cscript \"" .. script .. "\""
end

local function startwith(str, startCheck)
    return string.sub(str, 1, string.len(startCheck)) == startCheck
end

local function clamp(value, min, max)
    return math.min(math.max(value, min), max)
end

local function dist(pos1, pos2)
    return math.sqrt(((pos1.x - pos2.x) ^ 2) + ((pos1.y - pos2.y) ^ 2) + ((pos1.z - pos2.z) ^ 2))
end

local function noBell(str)
    local newstr = {}
    for i = 1, #str do
        local char = str:sub(i, i)
        if char == bellChar then
            table.insert(newstr, "<bell>")
        else
            table.insert(newstr, char)
        end
    end
    return table.concat(newstr)
end

local function debugPrint(...)
    if debugMode then
        print(...)
    end
end

local function wait(time)
    local startTime = os.clock()
    repeat
    until os.clock() - startTime > time
end

local function spcall(func, ...)
    local result = {pcall(func, ...)}
    if result[1] then
        return unpack(result, 2)
    else
        error(result[2], 3)
    end
end

local function tableToPrint(tbl)
    local newtbl = {}
    for i, v in ipairs(tbl) do
        local ok, result = pcall(type, v)
        if ok and result == "number" then
            newtbl[i] = v
        else
            ok, result = pcall(tostring, v)
            if ok then
                newtbl[i] = result
            else
                newtbl[i] = "<undeserialized>"
            end
        end
    end
    return newtbl
end

local function logCall(tag, func, ...)
    print("----------------------------------------------")
    print("call", tag, ":", tableToPrint({...}))
    local result = {spcall(func, ...)}
    print("result", tag, ":", tableToPrint(result))
    print("----------------------------------------------")
    return unpack(result)
end

local function logExecute(...)
    return logCall("os.execute", os.execute, ...)
end

local function startWith(str, start)
    if str:sub(1, #start) == start then
        return true
    end
end

local function endWith(str, endCheck)
    return string.sub(str, string.len(str) - (string.len(endCheck) - 1), string.len(str)) == endCheck
end

local function tableExists(tbl, val)
    for k, v in pairs(tbl) do
        if v == val then
            return true, k
        end
    end
    return false
end

local function trimLeft(str, trimLetters)
    local newstr = {}
    local allowTrim = true
    for i = 1, string.len(str) do
        local char = string.sub(str, i, i)
        if allowTrim then
            if not tableExists(trimLetters, char) then
                table.insert(newstr, char)
                allowTrim = false
            end
        else
            table.insert(newstr, char)
        end
    end
    return table.concat(newstr)
end

local function trimRight(str, trimLetters)
    local newstr = {}
    local allowTrim = true
    for i = string.len(str), 1, -1 do
        local char = string.sub(str, i, i)
        if allowTrim then
            if not tableExists(trimLetters, char) then
                table.insert(newstr, 1, char)
                allowTrim = false
            end
        else
            table.insert(newstr, 1, char)
        end
    end
    return table.concat(newstr)
end

local function getPathExtension(path)
    local extension = {}
    for i = #path, 1, -1 do
        local char = path:sub(i, i)
        if char == "." then
            return table.concat(extension)
        else
            table.insert(extension, 1, char)
        end
    end
end

local function getPathExtensionWithDot(path)
    local extension = {}
    for i = #path, 1, -1 do
        local char = path:sub(i, i)
        table.insert(extension, 1, char)
        if char == "." then
            return table.concat(extension)
        end
    end
end

local function getPathName(path)
    local name = {}
    for i = #path - #getPathExtensionWithDot(path), 1, -1 do
        local char = path:sub(i, i)
        if char == "/" or char == "\\" then
            return table.concat(name)
        else
            table.insert(name, 1, char)
        end
    end
end

local function hideExtension(name)
    return getPathName("/" .. name)
end

local function trim(str, list)
    str = trimLeft(str, list)
    str = trimRight(str, list)
    return str
end

local function checkArg(n, have, ...)
    have = type(have)
    local tbl = {...}
    for _, t in ipairs(tbl) do
        if have == t then
            return
        end
    end
    error(string.format("bad argument #%d (%s expected, got %s)", n, table.concat(tbl, " or "), have), 3)
end

local readonlyList = {
    "description.json"
}

local readonly_trimLetters_path = {}
local readonly_trimLetters = {}

do
    local function isAllowedChar(char, allowedChars)
        if allowedChars[char] then
            return true
        end
        local byte = char:byte()
        return (byte >= 48 and byte <= 57) or  -- Цифры 0-9
            (byte >= 65 and byte <= 90) or  -- Заглавные буквы A-Z
            (byte >= 97 and byte <= 122)    -- Строчные буквы a-z
    end

    local allowedChars = {
        ["$"] = true
    }

    for i = 0, 255 do
        local char = string.char(i)
        if not isAllowedChar(char, allowedChars) then
            table.insert(readonly_trimLetters_path, char)
        end
        if not isAllowedChar(char, {}) then
            table.insert(readonly_trimLetters, char)
        end
    end
end

local function isReadOnly(gamepath)
    if gamepath:sub(1, 1) ~= "$" then
        return true
    end
    gamepath = gamepath:lower()
    gamepath = gamepath:gsub("\\", "/")
    while gamepath:sub(#gamepath, #gamepath) == "/" do
        gamepath = gamepath:sub(1, #gamepath - 1)
    end
    local tblPath = {{}}
    for i = 1, #gamepath do
        local char = gamepath:sub(i, i)
        if char == "/" then
            if #tblPath[#tblPath] > 0 then
                table.insert(tblPath, {})
            end
        else
            table.insert(tblPath[#tblPath], char)
        end
    end
    for i, tblPathPart in ipairs(tblPath) do
        tblPath[i] = trim(table.concat(tblPathPart), readonly_trimLetters)
    end
    gamepath = table.concat(tblPath, "/")
    gamepath = trim(gamepath, readonly_trimLetters_path)
    for _, readonlyFile in ipairs(readonlyList) do
        if endWith(gamepath, "/" .. readonlyFile) then
            return true
        end
    end
    return false
end

local function realBadCheck(path)
    if path:find("%.%.") and not startWith(path, "../../../workshop/content/") then
        --print("real-bad-path (1):", path)
        --return true
    elseif path:find("%/%/") or path:find("%\"") or path:find("%'") or path:find("%|") or path:find("%&") then
        print("real-bad-path (2):", path)
        return true
    end
    return false
end

local function nameBadCheck(path)
    if path:find("%.%.") or path:find("%\\") or path:find("%/") or path:find("%\"") or path:find("%'") or path:find("%&") then
        print("bad-name:", path)
        return true
    end
    return false
end

local function gameBadCheck(path)
    if path:find("%.%.") or path:find("%\\") or path:find("%/%/") or not path:find("%/") or path:find("%\"") or path:find("%'") or path:find("%&") then
        print("game-bad-path:", path)
        return true
    end
    return false
end

local function cmdEscapeWithoutCheck(path)
    return "\"" .. path .. "\""
end

local function cmdEscape(path)
    if realBadCheck(path) then
        error("invalid path")
    end

    return cmdEscapeWithoutCheck(path)
end

local function fpathWithoutCheck(path)
    path = path:gsub("/", "\\")
    if path:sub(#path, #path) == "\\" then
        path = path:sub(1, #path - 1)
    end

    return path
end

local function fpath(path)
    if realBadCheck(path) then
        error("invalid path")
    end

    return fpathWithoutCheck(path)
end

local function getContentRealPath(contentUuid)
    local regdata = registeredContents[contentUuid]
    if regdata then
        local workshopPath = workshopFolder .. regdata[1]
        local localPath
        if regdata.type == "mod" then
            localPath = localModsFolder .. regdata[2]
        elseif regdata.type == "blueprint" then
            localPath = localBlueprintsFolder .. contentUuid
        end
        if localPath and betterDLL.filesystem_exists(localPath) then
            return localPath, 0
        elseif betterDLL.filesystem_exists(workshopPath) then
            return workshopPath, 1
        else
            local err = "couldn't find the " .. contentUuid .. " content"
            print(err)
            print("workshop path: ", workshopPath)
            print("local path: ", localPath)
            error(err)
        end
    else
        error("the " .. contentUuid .. " content is not registered")
    end
end

local function getRealPath(smPath, noContent, rootActionAllow)
    checkArg(1, smPath, "string")
    checkArg(2, noContent, "boolean", "nil")

    if smPath:find("%.%.") then
        error("'..' is not supported by betterAPI")
    elseif gameBadCheck(smPath) then
        error("invalid path")
    end
    
    if smPath:sub(1, 1) == "$" then
        if isReadOnly(smPath) then
            error(fileReadonly)
        elseif noContent then
            error("working with content files is not available from this method")
        else
            if startWith(smPath, "$CONTENT_DATA") then
                error("$CONTENT_DATA is not supported, use $CONTENT_UUID")
            elseif startWith(smPath, "$CONTENT_") then
                local contentUuid = smPath:sub(smPath:find("%_") + 1, smPath:find("%/") - 1)
                local lpath = smPath:sub(smPath:find("%/"), #smPath)
                local realPath = getContentRealPath(contentUuid)
                return fpath(realPath .. lpath)
            else
                error(smPath:sub(1, smPath:find("%/") - 1) .. " is not supported, use $CONTENT_UUID")
            end
        end
    elseif smPath:sub(1, 1) == "/" then
        if #smPath == 1 and not rootActionAllow then
            error("it is not possible to perform an action with the betterFS root directory")
        end
        return fpath(betterFsFolder .. smPath:sub(2, #smPath))
    else
        error("the path must start with '$' or '/'")
    end
end

local function tableCopyRecurse(tbl)
    local newtbl = {}
    for k, v in pairs(tbl) do
        if type(v) == "table" then
            newtbl[k] = tableCopyRecurse(v)
        else
            newtbl[k] = v
        end
    end
    return newtbl
end

local function tableCopy(tbl)
    local newtbl = {}
    for k, v in pairs(tbl) do
        newtbl[k] = v
    end
    return newtbl
end

local function tableCompare(tbl1, tbl2)
    for k, v in pairs(tbl1) do
        if tbl2[k] ~= v then
            return false
        end
    end

    for k, v in pairs(tbl2) do
        if tbl1[k] ~= v then
            return false
        end
    end

    return true
end

local function tableProtect(tbl)
    local newtbl = {}
    for k, v in pairs(tbl) do
        if type(v) == "table" then
            newtbl[k] = tableProtect(v)
        else
            newtbl[k] = v
        end
    end
    return setmetatable({}, {__index = newtbl, __newindex = function()
        error("this table is read-only", 2)
    end})
end

local function xor(...)
    local state = false
    for _, flag in ipairs({...}) do
        if flag then
            state = not state
        end
    end
    return state
end

local function checkUuid(str)
    if #str ~= #nullUuid then
        return false
    end

    for i = 1, #nullUuid do
        local need = nullUuid:sub(i, i)
        local char = str:sub(i, i)

        if xor(need == "-", char == "-") or (need ~= "-" and not tonumber(char, 16)) then
            return false
        end
    end
    
    return true
end

local function rawWriteFile(path, content)
    local file, err = io.open(path, "wb")
    if not file then return nil, tostring(err or "unknown error") end
    file:write(tostring(content))
    file:close()
    return true
end

local function rawList(path)
    local dir, err = logCall("io.popen", io.popen, "chcp 1251|dir /a /b " .. cmdEscape(path))
    if not dir then
        return nil, tostring(err or "unknown error")
    end

    local tbl = {}
    for filename in dir:lines() do
        table.insert(tbl, filename)
    end
    dir:close()
    return tbl
end

local function rawCopy(fromPath, toPath)
    if betterDLL.filesystem_isDir(fromPath) then
        betterDLL.filesystem_mkdir(toPath)
        return logExecute("xcopy " .. cmdEscape(fromPath) .. " " .. cmdEscape(toPath) .. " /e /c /y") == 0
    else
        return logExecute("copy " .. cmdEscape(fromPath) .. " " .. cmdEscape(toPath) .. " /y") == 0
    end
end

local function tempFile(content, exp)
    local path = betterTempGlobalPath .. "/" .. randomName() .. (exp and ("." .. exp) or "")
    rawWriteFile(path, content)
    return path
end

local function binNumberFormat(byteCount, num)
    local bytes = {}
    for i = 0, byteCount - 1 do
        table.insert(bytes, string.char(bit.band(bit.rshift(num, i * 8), 0xFF)))
    end
    return table.concat(bytes)
end

local checkFormat_allowedChars = {}
for char = string.byte("A"), string.byte("Z") do
    checkFormat_allowedChars[string.char(char)] = true
end
for char = string.byte("a"), string.byte("z") do
    checkFormat_allowedChars[string.char(char)] = true
end
for char = string.byte("0"), string.byte("9") do
    checkFormat_allowedChars[string.char(char)] = true
end
local function checkFormat(format)
    if #format > 8 then
        error("the maximum extension length is 8 characters", 3)
    end

    for i = 1, #format do
        local char = format:sub(i, i)
        if not checkFormat_allowedChars[char] then
            error("the \"" .. char .. "\" character is not allowed before being used in extensions", 3)
        end
    end
end

local currentGameSettings = {}
local currentGameSettingsTick
local function getGameSettings()
    local ctick = game_getCurrentTick()
    if not currentGameSettingsTick or ctick - currentGameSettingsTick > 40 then
        local gameSettingsText = rawReadFile(gameSettingsPath)
        if gameSettingsText then
            currentGameSettings = json_parseJsonString(gameSettingsText)
        end
        currentGameSettingsTick = ctick
    end

    return currentGameSettings
end

local function ipairsEx(...)
    local tables = {...}
    local tbl = {}
    for _, ltbl in ipairs(tables) do
        for _, v in ipairs(ltbl) do
            table.insert(tbl, v)
        end
    end

    return ipairs(tbl)
end
 
local function asyncExecute(dir, path, ...)
    local escapeReplace = {
        ["\\"] = "\\\\",
        ["\""] = "\\\"",
    }

    local function getArgs(...)
        local tbl = {...}
        for i, v in ipairs(tbl) do
            local ltbl = {" \""}
            for i = 1, string.len(v) do
                local char = string.sub(v, i, i)
                table.insert(ltbl, escapeReplace[char] or char)
            end
            table.insert(ltbl, "\"")
            tbl[i] = table.concat(ltbl)
        end
        return table.concat(tbl, "")
    end

    local function writeBat(dir, path, ...)
        local localBatPath = "BetterTemp\\" .. math.floor(math.random(0, 99999999)) .. ".bat"
        local batPath = workingDirectory .. "/" .. localBatPath
        local cmd = "@echo off\ncd \"" .. workingDirectory .. "\"\ncd \"" .. dir .. "\"\n\"" .. path .. "\"" .. getArgs(...) .. "\ndel \"" .. batPath .. "\""
        rawWriteFile(batPath, cmd)
        return "\"" .. batPath .. "\""
    end

    return os.execute("START /B CMD /C CALL " .. writeBat(dir, path, ...))
end

--------------------------------------------------- protection

local modsWhitelist = json_parseJsonString(rawReadFile("modsWhitelist.json"))
local modsAllowed = {}
local function isModInWhilelist(modsLists)
    local trace = debug.traceback()
    local cacheData = modsAllowed[trace]
    if cacheData and tableCompare(cacheData[2], modsLists) then
        return true, cacheData[1]
    else
        local description = json_open("$CONTENT_DATA/description.json")
        cacheData = modsAllowed[description.localId]
        if cacheData and tableCompare(cacheData[2], modsLists) then
            modsAllowed[trace] = cacheData
            return true, cacheData[1]
        else
            print("(betterAPI) -------- checking mod on whitelist: ", description.name, description.localId)
            modsAllowed[trace] = nil
            modsAllowed[description.localId] = nil
            for _, mod in ipairsEx(unpack(modsLists)) do
                print("comparison with", mod)
                local ok = true
                for k, v in pairs(mod) do
                    if k ~= "apis" and description[k] ~= v then
                        print("bad parameter", k, "need", description[k], "there is", v)
                        ok = false
                        break
                    end
                end
                if ok then
                    print("(betterAPI) -------- the mod was successfully FOUND in the whitelist: ", description.name)
                    local cacheData = {mod.apis, tableCopy(modsLists)}
                    modsAllowed[trace] = cacheData
                    modsAllowed[description.localId] = cacheData
                    return true, mod.apis
                end
            end
            print("(betterAPI) -------- the mod was NOT found in the whitelist:" .. string.char(7), description.name)
        end
    end
end

local function getSelfModName()
    return json_open("$CONTENT_DATA/description.json").name
end

local function modCheckRaw(modsLists, ...)
    local requiredAPIcategory = {...}
    local allowed, apis = isModInWhilelist(modsLists)
    if not allowed then
        error("(" .. getSelfModName() .. ") your mod does not have permission to use betterAPI from bananapen. contact bananapen for permission to use betterAPI. if you are trying to use the API from an extension, then you probably need to contact the extension developer to gain access.")
    end
    if apis then
        for _, requiredAPI in ipairs(requiredAPIcategory) do
            local finded = false
            for i, v in ipairs(apis) do
                if v == requiredAPI then
                    finded = true
                    break
                end
            end
            if not finded then
                error("(" .. getSelfModName() .. ") you don't have access to " .. requiredAPI .. " in betterAPI or extension")
            end
        end
    end
end

local function modCheckCEx(mods, ...)
    modCheckRaw({mods}, ...)
end

local function modCheckEx(mods, ...)
    modCheckRaw({modsWhitelist, mods}, ...)
end

local function modCheck(...)
    modCheckRaw({modsWhitelist}, ...)
end

function sm.json.save(root, path)
    checkArg(1, root, "table")
    checkArg(2, path, "string")
    if isReadOnly(path) then
        error(fileReadonly, 2)
    end
    return json_save(root, path)
end

--------------------------------------------------- audio api

local function findAudioScript(object)
    return audioScripts[object] or error("the audioobject was not found", 3)
end

local function createAudio(audioContent, audioType, wait, deleteAfterDestroy, checkFileExists)
    local audioScript = {
        loop = false,
        volume = 0,
        balance = 0,
        pitch = 0,
        speed = 1,
        rate = 1,
        deleteAfterDestroy = deleteAfterDestroy,
        checkFileExists = checkFileExists,
        wait = wait
    }
    if deleteAfterDestroy or checkFileExists then
        audioScript.path = audioContent
    end
    audioScript.object = setmetatable({}, {__index = better.audio})
    audioScript.handle = betterDLL.audio_create()
    audioScript.audioContent = audioContent
    audioScript.audioType = audioType
    audioScript.ownerCounter = {ownerCounter=1}
    audioScripts[audioScript.object] = audioScript
    return audioScript.object
end

local function createAudioStream(sampleRate, byteRate, channelsCount)
    local audioScript = {
        loop = false,
        volume = 0,
        balance = 0,
        pitch = 0,
        speed = 1,
        rate = 1
    }
    audioScript.object = setmetatable({}, {__index = better.audio})
    audioScript.audioType = AUDIO_TYPE_NONE
    audioScript.destroyAudio = {}
    audioScript.isStream = true
    audioScript.sampleRate = sampleRate
    audioScript.byteRate = byteRate
    audioScript.channelsCount = channelsCount
    audioScripts[audioScript.object] = audioScript
    return audioScript.object
end

local function spatial_audio(listener_position, listener_direction, sound_position)
    local distance = math.sqrt((sound_position.x - listener_position.x)^2 +
                                (sound_position.y - listener_position.y)^2 +
                                (sound_position.z - listener_position.z)^2)
  
    local listener_direction_x, listener_direction_y = listener_direction.x, listener_direction.y
    local sound_position_x, sound_position_y, sound_position_z = sound_position.x, sound_position.y, sound_position.z
    local vector_x, vector_y, vector_z = sound_position_x - listener_position.x, sound_position_y - listener_position.y, sound_position_z - listener_position.z 
    local balance = listener_direction_y * vector_x / math.sqrt(listener_direction_x^2 + listener_direction_y^2) -
    listener_direction_x * vector_y / math.sqrt(listener_direction_x^2 + listener_direction_y^2)
    balance = math.max(math.min(balance, 1.0), -1.0)
    return balance
end

local function updateAudio(audioScript, gameSettings)
    if audioScript.audioType == AUDIO_TYPE_NONE then
        if audioScript.isStream then
            local ctick = game_getCurrentTick()

            if audioScript.pcmstream then
                findAudioScript(audioScript.pcmstream).spatial = audioScript.spatial
                audioScript.pcmstream:update()
            end
        
            for audio, deadline in pairs(audioScript.destroyAudio) do
                if ctick > deadline then
                    audio:destroy()
                    audioScript.destroyAudio[audio] = nil
                end
            end
        end
        return
    end

    if not audioScript.loaded then
        if audioScript.audioType == AUDIO_TYPE_URL then
            betterDLL.audio_setUrl(audioScript.handle, audioScript.audioContent)
        elseif audioScript.audioType == AUDIO_TYPE_FILE then
            betterDLL.audio_setPath(audioScript.handle, audioScript.audioContent)
        elseif audioScript.audioType == AUDIO_TYPE_PCM then
            betterDLL.audio_setPcm(audioScript.handle, audioScript.audioContent.pcmContent, #audioScript.audioContent.pcmContent, audioScript.audioContent.sampleRate, audioScript.audioContent.byteRate, audioScript.audioContent.channelsCount)
        elseif audioScript.audioType == AUDIO_TYPE_RAM then
            betterDLL.audio_setRam(audioScript.handle, audioScript.audioContent, #audioScript.audioContent)
        end
        audioScript.loaded = true
    end

    local spatial = audioScript.spatial
    local gVolume = audioScript.volume * (gameSettings.MasterVolume or 1) * (gameSettings.EffectVolume or 1)
    if spatial then
        local ear = spatial[1]
        local volume = 0
        local eardir = spatial[3]
        local balance = eardir and 0
        for i, speaker in ipairs(spatial[2]) do
            --volume = volume + ((speaker[2] - dist(ear, speaker[1])) / speaker[2])
            local speakerDistance = dist(ear, speaker[1])
            local maxDistance = speaker[2]
            if speakerDistance < maxDistance then
                local speakerVolume = 1 - (math.log10(speakerDistance) / math.log10(maxDistance))
                if speakerVolume < 0 then
                    speakerVolume = 0
                end
                volume = volume + speakerVolume
            end

            if balance then
                balance = balance + (spatial_audio(ear, eardir, speaker[1]) * 0.6)
            end
        end
        volume = volume * gVolume

        betterDLL.audio_setVolume(audioScript.handle, volume)
        betterDLL.audio_setBalance(audioScript.handle, clamp(balance, -1, 1))
    else
        betterDLL.audio_setVolume(audioScript.handle, gVolume)
        betterDLL.audio_setBalance(audioScript.handle, audioScript.balance)
    end

    betterDLL.audio_setLoop(audioScript.handle, audioScript.loop)
    betterDLL.audio_setRate(audioScript.handle, audioScript.rate)
    betterDLL.audio_setPitch(audioScript.handle, audioScript.pitch)
    betterDLL.audio_setSpeed(audioScript.handle, audioScript.speed)

    local playState = betterDLL.audio_getState(audioScript.handle)
    if audioScript.newPosition and playState == 1 then
        local length = audioScript.object:getLength()
        if audioScript.newPosition < 0 then audioScript.newPosition = 0 end
        if audioScript.newPosition > length then audioScript.newPosition = length end
        if betterDLL.audio_setPosition(audioScript.handle, audioScript.newPosition) then
            audioScript.newPosition = nil
        end
    end

    betterDLL.audio_update(audioScript.handle)
end

--[[
local function vbsNumber(number)
    local maxnumber = 126
    if number > maxnumber then
        local add = number - maxnumber
        if add > maxnumber then
            return string.char(maxnumber) .. string.char(maxnumber)
        end
        return string.char(maxnumber) .. string.char(add)
    else
        return string.char(number) .. string.char(0)
    end
end

local function genBalance(balance)
    balance = math.floor((((balance + 1) / 2) * 255) + 0.5)
    if balance < 0 then
        balance = 0
    elseif balance > 255 then
        balance = 255
    end
    return "b" .. vbsNumber(balance)
end

local function genVolume(volume)
    volume = math.floor((volume * 255) + 0.5)
    if volume < 0 then
        volume = 0
    elseif volume > 255 then
        volume = 255
    end
    return "v" .. vbsNumber(volume)
end
]]

--[[
    listener_direction_y * vector_x / math.sqrt(listener_direction_x^2 + listener_direction_y^2) -
    listener_direction_x * vector_y / math.sqrt(listener_direction_x^2 + listener_direction_y^2)
]]

--------------------------------------------------- custom gui function

local temporaryLayouts = {}

local createGuiFromLayout = sm.gui.createGuiFromLayout
local function createGuiFromString(xml, destroyOnClose, settings)
    local uuid = randomName()
    local path = betterTempDataLocalPath .. "/" .. uuid .. ".layout"
    local file, err = io.open(path, "w")
    if file and not err then
        file:write(xml)
        file:close()
        local gui = createGuiFromLayout("$GAME_DATA/BetterTempData/" .. uuid .. ".layout", destroyOnClose, settings)
        table.insert(temporaryLayouts, {path = path})
        return gui
    end
end

local function createGuiFromFile(path, destroyOnClose, settings)
    return createGuiFromString(assert(rawReadFile(path)), destroyOnClose, settings)
end

--------------------------------------------------- apikey

local _keydata = {}
local _apikey = {}
local function _apikey_table(category)
    _apikey[category] = _apikey[category] or {}
    return _apikey[category]
end

local function _apikey_dataTable(category)
    _keydata[category] = _keydata[category] or {}
    return _keydata[category]
end

local function apikey_check(category, apikey)
    local apikeys = _apikey_table(category)
    return not not apikeys[apikey]
end

local function apikey_checkErr(category, apikey)
    assert(apikey_check(category, apikey), "invalid API key")
end

local function apikey_revoke(category, apikey)
    local apikeys = _apikey_table(category)
    local keydataTable = _apikey_dataTable(category)
    apikeys[apikey] = nil
    keydataTable[apikey] = nil
end

local function apikey_revokeAll(category)
    if category then
        _apikey[category] = {}
        _keydata[category] = {}
    else
        _apikey = {}
        _keydata = {}
    end
end

local function apikey_gen(category)
    local apikeys = _apikey_table(category)
    local keydataTable = _apikey_dataTable(category)

    local apikey = {} --Yes, the apikey is just an empty table
    apikeys[apikey] = true
    keydataTable[apikey] = {}
    return apikey
end

local function apikey_getKeyData(category, apikey)
    local keydataTable = _apikey_dataTable(category)
    return keydataTable[apikey]
end

--------------------------------------------------- permission system

local function _createPermissionXml(yesName)
    return [[<?xml version="1.0" encoding="UTF-8"?>
<MyGUI type="Layout" version="3.2.0">
    <Widget type="Widget" skin="skin_Default" position_real="0 0.0048828125 0.458984375 0.56640625" name="BackPanel">
        <Property key="InheritsAlpha" value="false"/>
        <Widget type="Widget" skin="LogicGateBG" position_real="0.061702127659574467 0.051724137931034482 0.87021276595744679 0.89655172413793105">
            <Property key="NeedKey" value="false"/>
            <Property key="InheritsAlpha" value="false"/>
            <Widget type="ImageBox" skin="ImageBox" position_real="0.47677261613691929 0.086538461538461536 0.063569682151589244 0.090384615384615383">
                <Property key="ImageTexture" value="gui_icon_popup_alert.png"/>
            </Widget>
            <Widget type="EditBox" skin="TextBox" position_real="0.23227383863080683 0.18269230769230768 0.52078239608801957 0.096153846153846159" name="Title">
                <Property key="FontName" value="SM_Button"/>
                <Property key="TextAlign" value="Center"/>
                <Property key="WordWrap" value="true"/>
                <Property key="Static" value="true"/>
                <Property key="MultiLine" value="true"/>
            </Widget>
            <Widget type="EditBox" skin="EditBoxEmpty" position_real="0.23227383863080683 0.28846153846153844 0.52567237163814184 0.27884615384615385" name="Message">
                <Property key="FontName" value="SM_Text"/>
                <Property key="WordWrap" value="true"/>
                <Property key="TextAlign" value="HCenter Top"/>
                <Property key="TextColour" value="0.564706 0.572549 0.572549"/>
                <Property key="ReadOnly" value="true"/>
                <Property key="Static" value="true"/>
            </Widget>
            <Widget type="Button" skin="PrimaryButton" position_real="0.53789731051344747 0.85576923076923073 0.21515892420537897 0.125" name="]] .. yesName .. [[">
                <Property key="Caption" value="#{MENU_YN_YES}"/>
                <Property key="FontName" value="SM_Button"/>
                <Property key="TextAlign" value="Center"/>
            </Widget>
            <Widget type="Button" skin="SecondaryButton" position_real="0.23227383863080683 0.86538461538461542 0.20782396088019561 0.11153846153846154" name="No">
                <Property key="Caption" value="#{MENU_YN_NO}"/>
                <Property key="FontName" value="SM_Button"/>
                <Property key="TextAlign" value="Center"/>
            </Widget>
            <Widget type="TextBox" skin="TextBox" position_real="0.46454767726161367 0.89423076923076927 0.36674816625916873 0.057692307692307696" name="Timer">
                <Property key="TextAlign" value="Center"/>
                <Property key="Enabled" value="false"/>
            </Widget>
            <Widget type="Button" skin="ButtonRightSkin" position_real="0.59902200488997559 0.67307692307692313 0.08557457212713937 0.067307692307692304" name="source_right"/>
            <Widget type="Button" skin="ButtonLeftSkin" position_real="0.30562347188264061 0.67307692307692313 0.08557457212713937 0.067307692307692304" name="source_left"/>
            <Widget type="TextBox" skin="TextBox" position_real="0.39119804400977998 0.67307692307692313 0.20782396088019561 0.067307692307692304" name="source_text">
                <Property key="TextAlign" value="Center"/>
                <Property key="FontName" value="SM_Button"/>
            </Widget>
            <Widget type="TextBox" skin="TextBox" position_real="0.23227383863080683 0.60576923076923073 0.52567237163814184 0.057692307692307696" name="source_title">
                <Property key="Caption" value="Select a source"/>
                <Property key="TextAlign" value="Center"/>
            </Widget>
            <Widget type="Button" skin="Button" position_real="0.23227383863080683 0.75 0.036674816625916873 0.04807692307692308" name="toggle1"/>
            <Widget type="TextBox" skin="TextBox" position_real="0.28117359413202936 0.75 0.47677261613691929 0.038461538461538464" name="toggle1_text">
                <Property key="FontName" value="SM_Label"/>
                <Property key="TextAlign" value="Left VCenter"/>
            </Widget>
            <Widget type="TextBox" skin="TextBox" position_real="0.012224938875305624 0.81730769230769229 0.97799511002444983 0.038461538461538464" name="note">
                <Property key="TextAlign" value="Center"/>
            </Widget>
        </Widget>
    </Widget>
    <CodeGeneratorSettings/>
</MyGUI>]]
end

local function createPermissionGui(shapeClass, self, title, message, callback, sources, toggles, note)
    if self._betterAPI_gui and sm.exists(self._betterAPI_gui) then
        self._betterAPI_gui:close()
        self._betterAPI_gui:destroy()
    end

    local yesName = randomName()
    local selected = 1
    local timer = 40 * 5
    local togglesCount = 1
    local togglesStates = {}

    function shapeClass:_betterAPI_no()
        self._betterAPI_gui:close()
    end

    function shapeClass:_betterAPI_yes(buttonName, b, a)
        if buttonName == yesName then
            self._betterAPI_gui:close()
            if sources then
                callback(selected, sources[selected], togglesStates)
            else
                callback(nil, nil, togglesStates)
            end
        else
            error("a potential attempt to abuse the betterAPI permission system")
        end
    end

    local gui = createGuiFromString(_createPermissionXml(yesName), true)
    gui:setButtonCallback("No", "_betterAPI_no")
    gui:setButtonCallback(yesName, "_betterAPI_yes")
    gui:setText("Title", "do you want to grant this shape access to \"" .. title .."\"?")
    gui:setText("Message", (message and (message .. "\n") or "") .. "to revoke all permissions, type in the chat /revoke")
    gui:setVisible(yesName, false)
    if note then
        gui:setVisible("note", true)
        gui:setText("note", note)
    else
        gui:setVisible("note", false)
    end

    function shapeClass:_betterAPI_toggle(toggleName)
        local index = tonumber(toggleName:sub(#toggleName, #toggleName))
        togglesStates[index] = not togglesStates[index]

        local toggleWidget = "toggle" .. index
        gui:setButtonState(toggleWidget, togglesStates[index])
    end

    for i = 1, togglesCount do
        gui:setVisible("toggle" .. i, false)
        gui:setVisible("toggle" .. i .. "_text", false)
    end

    if toggles then
        for i, text in ipairs(toggles) do
            togglesStates[i] = false

            local toggleWidget = "toggle" .. i
            local textWidget = "toggle" .. i .. "_text"
            gui:setVisible(toggleWidget, true)
            gui:setVisible(textWidget, true)

            gui:setButtonState(toggleWidget, false)
            gui:setText(textWidget, text)

            gui:setButtonCallback(toggleWidget, "_betterAPI_toggle")
        end
    end

    if sources then
        local function updateSourceText()
            gui:setText("source_text", sources[selected])
        end
        updateSourceText()

        function shapeClass:_betterAPI_left()
            selected = selected - 1
            if selected < 1 then
                selected = #sources
            end
            updateSourceText()
        end

        function shapeClass:_betterAPI_right()
            selected = selected + 1
            if selected > #sources then
                selected = 1
            end
            updateSourceText()
        end

        gui:setButtonCallback("source_left", "_betterAPI_left")
        gui:setButtonCallback("source_right", "_betterAPI_right")
    else
        gui:setVisible("source_title", false)
        gui:setVisible("source_text", false)
        gui:setVisible("source_left", false)
        gui:setVisible("source_right", false)
    end

    self._betterAPI_gui = gui
    self._betterAPI_tick = function()
        if sm.exists(gui) then
            timer = timer - 1
            if timer <= 0 then
                gui:setVisible(yesName, true)
                gui:setText("Timer", "")
            else
                gui:setText("Timer", "wait " .. math.floor((timer / 40) + 0.5) .. " seconds")
            end
        end
    end

    gui:open()
end

--------------------------------------------------- internal api (available only for betterAPI extensions)

_G.bext = {
    loadDLL = betterDLL.loadDLL,
    modCheck = modCheck,
    modCheckEx = modCheckEx,
    modCheckCEx = modCheckCEx,
    registerHandler_exit = function(func)
        exitHandlers[func] = true
    end,
    registerHandler_tick = function(func)
        tickHandlers[func] = true
    end
}

bext.registerHandler_exit(clearTemp)

--------------------------------------------------- user api

local mousecodes = {
    lmb = 0x01,
    rmb = 0x02,
    mmb = 0x04,
    x1_mb = 0x05,
    x2_mb = 0x06
}

local keycodes = {
    backspace = 0x08,
    tab = 0x09,
    enter = 0x0D,
    shift = 0x10,
    ctrl = 0x11,
    alt = 0x12,
    capsLock = 0x14,
    esc = 0x1B,
    space = 0x20,
    arrow_l = 0x25,
    arrow_r = 0x27,
    arrow_u = 0x26,
    arrow_d = 0x28,
    zero = 0x30,
    one = 0x31,
    two = 0x32,
    three = 0x33,
    four = 0x34,
    five = 0x35,
    six = 0x36,
    seven = 0x37,
    eight = 0x38,
    nine = 0x39,			
    a = 0x41,
    b = 0x42,
    c = 0x43,
    d = 0x44,
    e = 0x45,
    f = 0x46,
    g = 0x47,
    h = 0x48,
    i = 0x49,
    j = 0x4A,
    k = 0x4B,
    l = 0x4C,
    m = 0x4D,
    n = 0x4E,
    o = 0x4F,
    p = 0x50,
    q = 0x51,
    r = 0x52,
    s = 0x53,
    t = 0x54,
    u = 0x55,
    v = 0x56,
    w = 0x57,
    x = 0x58,
    y = 0x59,
    z = 0x5A,
    win_l = 0x5B,
    win_r = 0x5C,
    num_0 = 0x60,
    num_1 = 0x61,
    num_2 = 0x62,
    num_3 = 0x63,
    num_4 = 0x64,
    num_5 = 0x65,
    num_6 = 0x66,
    num_7 = 0x67,
    num_8 = 0x68,
    num_9 = 0x69,
    f1 = 0x70,
    f2 = 0x71,
    f3 = 0x72,
    f4 = 0x73,
    f5 = 0x74,
    f6 = 0x75,
    f7 = 0x76,
    f8 = 0x77,
    f9 = 0x78,
    f10 = 0x79,
    f11 = 0x7A,
    f12 = 0x7B,
    f13 = 0x7C,
    f14 = 0x7D,
    f15 = 0x7E,
    f16 = 0x7F,
    f17 = 0x80,
    f18 = 0x81,
    f19 = 0x82,
    f20 = 0x83,
    f21 = 0x84,
    f22 = 0x85,
    f23 = 0x86,
    f24 = 0x87,
    shift_l = 0xA0,
    shift_r = 0xA1,
    ctrl_l = 0xA2,
    ctrl_r = 0xA3,
    alt_l = 0xA4,
    alt_r = 0xA5
}

local oldTickTime
local optimizationState
local ttsCache

local screenWidth, screenHeight = 1920, 1080
local realScreenSize = false

local thread_mt = {
    __index = function(self, key)
        return better.thread[key]
    end
}

local function textEditor(exp, text)
    checkArg(1, exp, "string")
    checkArg(2, text, "string")
    local filePath = betterTempLocalPath .. "/textEditor_" .. randomStr() .. "." .. exp
    os.remove(filePath)
    rawWriteFile(filePath, text)
    os.execute("START /B CMD /C CALL \"%UserProfile%\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe\" " .. filePath, "r")
    local deleted = false
    return function (delete)
        if delete then
            deleted = true
            os.remove(filePath)
        elseif not deleted then
            return rawReadFile(filePath)
        end
    end
end

local oldDynamicloadTime

better = {
    version = tonumber(currentVersion),

    isAvailable = function()
        return not not (isModInWhilelist({modsWhitelist}))
    end,

    tick = function()
        local currentTickTime = game_getCurrentTick()
        if currentTickTime ~= oldTickTime then
            if not oldDynamicloadTime or currentTickTime - oldDynamicloadTime > 40 then
                extensionDynamicload()
                oldDynamicloadTime = currentTickTime
            end

            if not sm.isServerMode() then
                if not realScreenSize then
                    screenWidth, screenHeight = sm.gui.getScreenSize()
                    realScreenSize = true
                end
            end
            
            local gameSettings = getGameSettings()

            betterDLL.tick()
            runHandlers(tickHandlers)

            for _, audioScript in pairs(audioScripts) do
                if not audioScript.checkFileExists or audioScript.fileExists or betterDLL.filesystem_exists(audioScript.path) then
                    audioScript.fileExists = true
                    if not audioScript.wait then
                        if audioScript.startWait then
                            audioScript.object:start()
                            audioScript.startWait = nil
                        end
                        if audioScript.pauseWait then
                            audioScript.object:pause()
                            audioScript.pauseWait = nil
                        end
                        updateAudio(audioScript, gameSettings)
                    else
                        audioScript.wait = audioScript.wait - 1
                        if audioScript.wait <= 0 then
                            audioScript.wait = nil
                        end
                    end
                end
            end

            oldTickTime = currentTickTime
        end
    end,

    registration = function(v1, v2, v3)
        local mod_uuid, mod_steamid, mod_foldername
        if not v2 and not v3 then
            local description = json_open("$CONTENT_DATA/description.json")

            mod_foldername = v1 or description.name
            checkArg(1, mod_foldername, "string", "nil")

            mod_uuid, mod_steamid = description.localId, tostring(description.fileId or "0000000000")
            if type(mod_uuid) ~= "string" then
                error("couldn't get the mod's UUID", 2)
            end
        else
            mod_uuid, mod_steamid, mod_foldername = v1, v2, v3
            checkArg(1, mod_uuid, "string", "Uuid")
            checkArg(2, mod_steamid, "string", "number")
            checkArg(3, mod_foldername, "string")
        end

        modCheck()
        mod_uuid = tostring(mod_uuid)
        mod_steamid = tostring(mod_steamid)
        mod_foldername = tostring(mod_foldername)

        if not checkUuid(mod_uuid) then
            error("invalid UUID", 2)
        elseif mod_steamid:find("[^%d]") then
            error("invalid steamID", 2)
        elseif nameBadCheck(mod_foldername) then
            error("invalid folder name", 2)
        end

        if not registeredContents[mod_uuid] then
            registeredContents[mod_uuid] = {mod_steamid, mod_foldername, type = "mod"}
            print("the mod has been successfully registered in betterAPI", mod_uuid, mod_steamid, mod_foldername)
        end

        return mod_uuid, mod_steamid, mod_foldername
    end,

    registrationBlueprint = function(uuid, steamid)
        checkArg(1, uuid, "string", "Uuid")
        checkArg(2, steamid, "string", "number", "nil")

        modCheck()
        uuid = tostring(uuid)
        steamid = steamid and tostring(steamid)

        if not registeredContents[uuid] then
            registeredContents[uuid] = {steamid, type = "blueprint"}
            print("the blueprint has been successfully registered in betterAPI", uuid, steamid)
        end
    end,

    autoRegistration = function(mod_foldername)
        --[[
        checkArg(1, mod_foldername, "string", "nil")
        modCheck()
        local description = json_open("$CONTENT_DATA/description.json")
        local mod_uuid, mod_steamid = description.localId, tostring(description.fileId or "0000000000")
        if type(mod_uuid) ~= "string" then
            error("couldn't get the mod's UUID", 2)
        end
        better.registration(mod_uuid, mod_steamid, mod_foldername or description.name)
        return mod_uuid, mod_steamid
        ]]
        checkArg(1, mod_foldername, "string", "nil")
        modCheck()
        local mod_uuid, mod_steamid = better.registration(mod_foldername)
        return mod_uuid, mod_steamid
    end,

    fast = function()
        modCheck("fast")

        if optimizationState ~= nil then
            return optimizationState
        end

        print("better.fast", pcall(function()
            if jit then
                print("better.fast: trying...")
                local ok, err = pcall(function ()
                    local optimizations = {
                        "fold",
                        "cse",
                        "dce",
                        "narrow",
                        "loop",
                        "fwd",
                        "dse",
                        "abc",
                        "sink",
                        "fuse",
                        "fma",
                        "hotloop=2",
                        "hotexit=2",
                        "maxmcode=131072",
                        "sizemcode=128",
                        "maxtrace=8096",
                        "maxrecord=8096",
                        "maxirconst=8096",
                        "maxside=8096",
                        "maxsnap=8096",
                        "tryside=32",
                        "instunroll=16",
                        "loopunroll=60"
                    }
                    jit.opt.start(2)
                    jit.opt.start(unpack(optimizations))
                    --collectgarbage("setpause", 1000)
                    --collectgarbage("setstepmul", 105)
                end)
                if ok then
                    print("better.fast: done!")
                else
                    print("better.fast: err: ", err)
                end
                optimizationState = ok
                return true
            else
                print("better.fast: JIT LIB NOT FOUND")
                return false
            end
        end))

        return optimizationState or false
    end,

    getSteamID = function()
        modCheck("getSteamID")
        return steamID
    end,

    loadstring = function (chunk, chunkname, env)
        checkArg(1, chunk, "string")
        checkArg(2, chunkname, "string", "nil")
        checkArg(3, env, "table")
        modCheck("loadstring")
        chunk = chunk or ""
        env = env or {}

        -- preventing bytecode loading
        if chunk:byte(1) == 27 then
            return nil, "binary bytecode prohibited"
        end

        -- checking for loading to the global environment (additional precautions)
        local code = load("return _G", chunkname, "t", env)
        local v1, v2 = pcall(code)
        if not v1 or v2 == _G then
            return nil, "load to the global environment is not possible"
        end

        -- if this variable exists in the code loaded with the same arguments, it means that it is somehow loaded into the global environment (need to prevent this)
        code = load("return _BETTERAPI_UNSAFE_GLOBAL_ENV", chunkname, "t", env)
        local v1, v2 = pcall(code)
        if not v1 or v2 then
            return nil, "load to the global environment is not possible"
        end

        -- loading the code
        return load(chunk, chunkname, "t", env)
    end,

    loadfile = function(path, env)
        checkArg(1, path, "string")
        checkArg(2, env, "table")
        modCheck("loadfile")
        local content, err = rawReadFile(getRealPath(path))
        if content then
            return better.loadstring(content, "=" .. path, env)
        end
        return nil, err
    end,

    setmetatable = function(...)
        modCheck("setmetatable")
        return setmetatable(...)
    end,
    getmetatable = function(...)
        modCheck("getmetatable")
        return getmetatable(...)
    end,
    date = function(...)
        modCheck("date")
        return os.date(...)
    end,

    textEditor_txt = function(text)
        checkArg(1, text, "string")
        modCheck("textEditor")
        return textEditor("txt", text)
    end,

    textEditor_lua = function(text)
        checkArg(1, text, "string")
        modCheck("textEditor")
        return textEditor("lua", text)
    end,

    filesystem = {
        show = function(path)
            checkArg(1, path, "string", "nil")
            modCheck("filesystem")
            local realPath = getRealPath(path or "/", false, true)
            if betterDLL.filesystem_isDir(realPath) then
                logExecute("explorer " .. cmdEscape(realPath))
                return true
            end
            return false
        end,
        readFile = function(path)
            checkArg(1, path, "string")
            modCheck("filesystem")
            return rawReadFile(getRealPath(path))
        end,
        writeFile = function(path, content)
            checkArg(1, path, "string")
            checkArg(2, content, "string")
            modCheck("filesystem")
            return rawWriteFile(getRealPath(path, true), content)
        end,
        makeDirectory = function(path)
            checkArg(1, path, "string")
            modCheck("filesystem")
            local realpath = getRealPath(path, true)
            betterDLL.filesystem_mkdir(realpath)
            return betterDLL.filesystem_isDir(realpath)
        end,
        isDirectory = function(path)
            checkArg(1, path, "string")
            modCheck("filesystem")
            return betterDLL.filesystem_isDir(getRealPath(path))
        end,
        exists = function(path)
            checkArg(1, path, "string")
            modCheck("filesystem")
            return betterDLL.filesystem_exists(getRealPath(path))
        end,
        list = function(path)
            checkArg(1, path, "string")
            modCheck("filesystem")
            return rawList(getRealPath(path, false, true))
        end,
        rename = function(fromPath, toPath)
            checkArg(1, fromPath, "string")
            checkArg(2, toPath, "string")
            modCheck("filesystem")
            return not not os.rename(getRealPath(fromPath, true), getRealPath(toPath, true))
        end,
        remove = function(path)
            checkArg(1, path, "string")
            modCheck("filesystem")
            local realpath = getRealPath(path, true)
            if not betterDLL.filesystem_exists(realpath) then return false end
            betterDLL.filesystem_asyncRemove(realpath)
            return true
        end,
        copy = function(fromPath, toPath)
            checkArg(1, fromPath, "string")
            checkArg(2, toPath, "string")
            modCheck("filesystem")
            return not not rawCopy(getRealPath(fromPath, true), getRealPath(toPath, true))
        end
    },

    algorithm = {
        base64_encode = betterDLL.base64_encode,
        base64_decode = betterDLL.base64_decode,
        sha256_text = betterDLL.sha256_text,
        sha256_binary = betterDLL.sha256_binary,
        sha256_file_text = function(path)
            checkArg(1, path, "string")
            modCheck("filesystem")
            return betterDLL.sha256_file_text(path)
        end,
        sha256_file_binary = function(path)
            checkArg(1, path, "string")
            modCheck("filesystem")
            return betterDLL.sha256_file_binary(path)
        end
    },

    nativeCoroutine = { --it is not recommended for use. IN NO CASE SHOULD YOU USE IT AT THE SAME TIME AS "coroutine"
        create = function(...)
            modCheck("coroutine")
            return coroutine.create(...)
        end,
        status = function(...)
            modCheck("coroutine")
            return coroutine.status(...)
        end,
        running = function(...)
            modCheck("coroutine")
            return coroutine.running(...)
        end,
        resume = function(...)
            modCheck("coroutine")
            return coroutine.resume(...)
        end,
        wrap = function(...)
            modCheck("coroutine")
            return coroutine.wrap(...)
        end,
        yield = function(...)
            modCheck("coroutine")
            return coroutine.yield(...)
        end
    },

    debug = { --taken from opencomputers (safety debug-api)
        getinfo = function(...)
            modCheck("debug")
            local result = debug.getinfo(...)
            if result then
                -- Only make primitive information available in the sandbox.
                return {
                    source = result.source,
                    short_src = result.short_src,
                    linedefined = result.linedefined,
                    lastlinedefined = result.lastlinedefined,
                    what = result.what,
                    currentline = result.currentline,
                    nups = result.nups,
                    nparams = result.nparams,
                    isvararg = result.isvararg,
                    name = result.name,
                    namewhat = result.namewhat,
                    istailcall = result.istailcall
                }
            end
        end,
        traceback = debug.traceback,
        -- using () to wrap the return of debug methods because in Lua doing this
        -- causes only the first return value to be selected
        -- e.g. (1, 2) is only (1), the 2 is not returned
        -- this is critically important here because the 2nd return value from these
        -- debug methods is the value itself, which opens a door to exploit the sandbox
        getlocal = function(...)
            modCheck("debug")
            return (debug.getlocal(...))
        end,
        getupvalue = function(...)
            modCheck("debug")
            return (debug.getupvalue(...))
        end
    },

    audio = {
        createFromFile = function(path)
            checkArg(1, path, "string")
            modCheck("audio")
            return createAudio(getRealPath(path), AUDIO_TYPE_FILE)
        end,
        createFromUrl = function(url)
            checkArg(1, url, "string")
            modCheck("audio", "http")
            if startwith(url, "http://") or startwith(url, "https://") then
                return createAudio(url, AUDIO_TYPE_URL)
            else
                error("incorrect url", 2)
            end
        end,
        createFromString = function(binstr)
            checkArg(1, binstr, "string")
            modCheck("audio")
            return createAudio(binstr, AUDIO_TYPE_RAM)
        end,
        createFromPcm = function(pcmContent, sampleRate, byteRate, channelsCount)
            checkArg(1, pcmContent, "string")
            checkArg(2, sampleRate, "number", "nil")
            checkArg(3, byteRate, "number", "nil")
            checkArg(4, channelsCount, "number", "nil")
            modCheck("audio")

            if #pcmContent == 0 then
                return createAudio(nil, AUDIO_TYPE_NONE)
            end

            sampleRate = math.floor(sampleRate or 8000)
            byteRate = math.floor(byteRate or 1)
            channelsCount = math.floor(channelsCount or 1)

            local wavHeader = {"RIFF"}
            table.insert(wavHeader, binNumberFormat(4, (44 + #pcmContent) - 8))
            table.insert(wavHeader, "WAVE")
            table.insert(wavHeader, "fmt ")
            table.insert(wavHeader, binNumberFormat(4, 16))
            table.insert(wavHeader, binNumberFormat(2, 1))
            table.insert(wavHeader, binNumberFormat(2, channelsCount))
            table.insert(wavHeader, binNumberFormat(4, sampleRate))
            table.insert(wavHeader, binNumberFormat(4, sampleRate * byteRate))
            table.insert(wavHeader, binNumberFormat(2, byteRate * channelsCount))
            table.insert(wavHeader, binNumberFormat(2, byteRate * 8))
            table.insert(wavHeader, "data")
            table.insert(wavHeader, binNumberFormat(4, #pcmContent))
            return better.audio.createFromString(table.concat(wavHeader) .. pcmContent)

            --return createAudio({sampleRate = sampleRate, byteRate = byteRate, channelsCount = channelsCount, pcmContent = pcmContent}, AUDIO_TYPE_PCM)
        end,
        createPcmStream = function(sampleRate, byteRate, channelsCount)
            checkArg(1, sampleRate, "number", "nil")
            checkArg(2, byteRate, "number", "nil")
            checkArg(3, channelsCount, "number", "nil")
            modCheck("audio")

            sampleRate = math.floor(sampleRate or 8000)
            byteRate = math.floor(byteRate or 1)
            channelsCount = math.floor(channelsCount or 1)

            return createAudioStream(sampleRate, byteRate, channelsCount)
        end,
        update = function(self)
            local audioScript = findAudioScript(self)
            if audioScript.checkFileExists and not audioScript.fileExists then
                return
            end
            updateAudio(audioScript, getGameSettings())
        end,
        flush = function(self, pcm)
            checkArg(1, pcm, "string", "nil")

            local selfAudioScript = findAudioScript(self)
            local oldAudio = selfAudioScript.pcmstream

            if pcm then
                selfAudioScript.pcmstream = better.audio.createFromPcm(pcm, selfAudioScript.sampleRate, selfAudioScript.byteRate, selfAudioScript.channelsCount)

                local pcmAudioScript = findAudioScript(selfAudioScript.pcmstream)
                pcmAudioScript.spatial = selfAudioScript.spatial
                selfAudioScript.pcmstream:setLoop(selfAudioScript.loop)
                selfAudioScript.pcmstream:setSpeed(selfAudioScript.speed)
                selfAudioScript.pcmstream:setRate(selfAudioScript.rate)
                selfAudioScript.pcmstream:setPitch(selfAudioScript.pitch)
                selfAudioScript.pcmstream:setVolume(selfAudioScript.volume)
                selfAudioScript.pcmstream:start()
            else
                selfAudioScript.pcmstream = nil
            end

            if oldAudio then
                oldAudio:setVolume(0)
                oldAudio:stop()
                selfAudioScript.destroyAudio[oldAudio] = sm.game.getCurrentTick() + 5
            end
        end,
        destroy = function(self)
            audioFree(findAudioScript(self))
        end,
        stop = function(self)
            local audioScript = findAudioScript(self)
            if audioScript.checkFileExists and not audioScript.fileExists then
                audioScript.startWait = nil
                audioScript.pauseWait = nil
                return
            end
            if audioScript.audioType == AUDIO_TYPE_NONE then return end
            self:update()
            betterDLL.audio_stop(audioScript.handle)
        end,
        start = function(self)
            local audioScript = findAudioScript(self)
            if audioScript.checkFileExists and not audioScript.fileExists then
                audioScript.startWait = true
                audioScript.pauseWait = nil
                return
            end
            if audioScript.audioType == AUDIO_TYPE_NONE then return end
            self:update()
            betterDLL.audio_start(audioScript.handle)
            self:update()
        end,
        pause = function(self)
            local audioScript = findAudioScript(self)
            if audioScript.checkFileExists and not audioScript.fileExists and audioScript.startWait then
                audioScript.pauseWait = true
                return
            end
            if audioScript.audioType == AUDIO_TYPE_NONE then return end
            self:update()
            betterDLL.audio_pause(audioScript.handle)
        end,
        setVolume = function(self, volume)
            volume = clamp(volume, 0, math.huge)
            local audioScript = findAudioScript(self)
            audioScript.volume = volume
        end,
        setBalance = function(self, balance)
            balance = clamp(balance, -1, 1)
            local audioScript = findAudioScript(self)
            audioScript.balance = balance
        end,
        setRate = function(self, rate)
            rate = clamp(rate, 0, math.huge)
            local audioScript = findAudioScript(self)
            audioScript.rate = rate
        end,
        setPitch = function(self, pitch)
            local audioScript = findAudioScript(self)
            audioScript.pitch = pitch
        end,
        setSpeed = function(self, speed)
            local audioScript = findAudioScript(self)
            audioScript.speed = speed
        end,
        setLoop = function(self, loop)
            local audioScript = findAudioScript(self)
            audioScript.loop = not not loop
        end,
        setPosition = function(self, second)
            local audioScript = findAudioScript(self)
            audioScript.newPosition = second
        end,
        seek = function(self, seek)
            local audioScript = findAudioScript(self)
            audioScript.newPosition = betterDLL.audio_getPosition(audioScript.handle) + seek
        end,
        updateSpatialSound = function(self, earpos, speakers, eardir)
            checkArg(2, earpos, "Vec3")
            checkArg(3, speakers, "table")
            checkArg(4, eardir, "Vec3", "nil")

            for i, v in ipairs(speakers) do
                if type(v) == "table" then
                    if type(v[1]) ~= "Vec3" then
                        error("the values of 1 in speaker " .. i .. " are not Vec3 (position)", 2)
                    elseif type(v[2]) ~= "number" then
                        error("the values of 2 in speaker " .. i .. " are not number (distance)", 2)
                    end
                else
                    error("speaker " .. i .. " is not a table. speaker table: {pos:vec3, dist:number}", 2)
                end
            end

            local audioScript = findAudioScript(self)
            audioScript.spatial = {earpos, tableCopyRecurse(speakers), eardir}
        end,
        noSpatialSound = function(self)
            local audioScript = findAudioScript(self)
            audioScript.spatial = nil
        end,
        getState = function(self)
            local audioScript = findAudioScript(self)
            if audioScript.audioType == AUDIO_TYPE_NONE then return 0 end
            return betterDLL.audio_getState(audioScript.handle)
        end,
        getPosition = function(self)
            local audioScript = findAudioScript(self)
            if audioScript.audioType == AUDIO_TYPE_NONE then return 0 end
            return betterDLL.audio_getPosition(audioScript.handle)
        end,
        getLength = function(self)
            local audioScript = findAudioScript(self)
            if audioScript.audioType == AUDIO_TYPE_NONE then return 0 end
            return betterDLL.audio_getLength(audioScript.handle)
        end,
        fork = function(self)
            local audioScript = findAudioScript(self)
            if audioScript.fork then
                return audioScript.fork()
            end
            return createAudio(audioScript.audioContent, audioScript.audioType)
        end
    },

    canvas = {
        alphaColor = -1,
        create = function(sizeX, sizeY)
            modCheck("canvas")
            return betterDLL.canvas_create(sizeX, sizeY)
        end,

        clear = betterDLL.canvas_clear,
        get = betterDLL.canvas_get,
        set = betterDLL.canvas_set,
        fill = betterDLL.canvas_fill,
        destroy = betterDLL.canvas_destroy,

        noUpdate = function(self)
            modCheck("canvas")
            betterDLL.canvas_noUpdate(self)
        end,
        update_raw = function(self, topLeftX, topLeftY, topRightX, topRightY, bottomLeftX, bottomLeftY, bottomRightX, bottomRightY)
            modCheck("canvas")
            betterDLL.canvas_update(self, topLeftX, topLeftY, topRightX, topRightY, bottomLeftX, bottomLeftY, bottomRightX, bottomRightY)
        end,
        update_2d = function(self, x, y, sizeX, sizeY)
            modCheck("canvas")
            local x2, y2 = (x + sizeX) - 1, (y + sizeY) - 1
            betterDLL.canvas_update(self, x, y, x2, y, x, y2, x2, y2)
        end,
        update_3d = function(self, worldPosition, upDir, leftDir, scaleX, scaleY)
            modCheck("canvas")
            upDir = upDir:normalize() * scaleY
            leftDir = leftDir:normalize() * scaleX
            local topLeftX, topLeftY = sm.render.getScreenCoordinatesFromWorldPosition(worldPosition + upDir + leftDir, screenWidth, screenHeight)
            local topRightX, topRightY = sm.render.getScreenCoordinatesFromWorldPosition((worldPosition + upDir) - leftDir, screenWidth, screenHeight)
            local bottomLeftX, bottomLeftY = sm.render.getScreenCoordinatesFromWorldPosition((worldPosition - upDir) + leftDir, screenWidth, screenHeight)
            local bottomRightX, bottomRightY = sm.render.getScreenCoordinatesFromWorldPosition(worldPosition - upDir - leftDir, screenWidth, screenHeight)
            betterDLL.canvas_update(self, topLeftX, topLeftY, topRightX, topRightY, bottomLeftX, bottomLeftY, bottomRightX, bottomRightY)
        end
    },

    thread = {
        new = function(code)
            checkArg(1, code, "string")
            modCheck("thread")
            local threadObj = setmetatable({}, thread_mt)
            threadList[threadObj] = betterDLL.thread_new(code)
            return threadObj
        end,
        threadTunnelSet = function(self, index, value)
            checkArg(2, index, "number")
            checkArg(3, value, "string", "number", "boolean", "nil")
            modCheck("thread")
            betterDLL.thread_set(assert(threadList[self]), index, value)
        end,
        threadTunnelGet = function(self, index)
            checkArg(2, index, "number")
            modCheck("thread")
            return betterDLL.thread_get(assert(threadList[self]), index)
        end,
        free = function(self)
            modCheck("thread")
            local result = betterDLL.thread_free(assert(threadList[self]))
            if result then
                threadList[self] = nil
            end
            return result
        end,
        kill = function(self)
            modCheck("thread")
            return betterDLL.thread_kill(assert(threadList[self]))
        end,
        result = function(self)
            modCheck("thread")
            return betterDLL.thread_result(assert(threadList[self]))
        end
    },

    mouse = {
        isLeft = function()
            modCheck("mouse")
            return betterDLL.getKeyState(mousecodes.lmb)
        end,
        isRight = function()
            modCheck("mouse")
            return betterDLL.getKeyState(mousecodes.rmb)
        end,
        isCenter = function()
            modCheck("mouse")
            return betterDLL.getKeyState(mousecodes.mmb)
        end
    },

    keyboard = {
        keys = keycodes,
        isKey = function(keycode)
            checkArg(1, keycode, "number")
            modCheck("keyboard")
            return betterDLL.getKeyState(keycode)
        end
    },

    openAI = {
        textRequest = function(apikey, model, prompt, request)
            checkArg(1, apikey, "string", "nil") --nil will try to use a custom server
            checkArg(2, model, "string", "nil")
            checkArg(3, prompt, "string")
            checkArg(4, request, "string")
            modCheck("openAI")

            local returnPath = betterTempLocalPath .. "/ai_return.txt"
            local promptPath = betterTempLocalPath .. "/ai_prompt.txt"
            local requestPath = betterTempLocalPath .. "/ai_request.txt"

            os.remove(returnPath)
            os.remove(promptPath)
            os.remove(requestPath)
            rawWriteFile(promptPath, prompt)
            rawWriteFile(requestPath, request)

            python.async("ai_textRequest.py", apikey or "", model or "")

            local timer
            return function ()
                if timer or betterDLL.filesystem_exists(returnPath) then
                    timer = (timer or 20) - 1
                end
                if timer == 0 then
                    local returnData = rawReadFile(returnPath)
                    os.remove(returnPath)
                    os.remove(promptPath)
                    os.remove(requestPath)
                    if type(returnData) == "string" then
                        return returnData
                    else
                        return nil, "failed to read file"
                    end
                end
            end
        end
    },

    videoCapture = {
        trigger = function(shapeClass, callbackName)
            checkArg(2, callbackName, "string")
            modCheck("videoCapture")
            
            if not shapeClass[callbackName] then
                error("invalid callback name", 2)
            end

            local shapeClass_client_onFixedUpdate = shapeClass.client_onFixedUpdate
            function shapeClass:client_onFixedUpdate(...)
                if self._betterAPI_tick then
                    self._betterAPI_tick()
                end

                if shapeClass_client_onFixedUpdate then
                    return shapeClass_client_onFixedUpdate(self, ...)
                end
            end

            local shapeClass_client_onDestroy = shapeClass.onDestroy
            function shapeClass:onDestroy(...)
                if apikey_check("videoCapture", self._betterAPI_videoCapture_apikey) then
                    apikey_revoke("videoCapture", self._betterAPI_videoCapture_apikey)
                    self._betterAPI_videoCapture_apikey = nil
                end

                if shapeClass_client_onDestroy then
                    return shapeClass_client_onDestroy(self, ...)
                end
            end

            function shapeClass:client_onInteract(_, state)
                if state then
                    if apikey_check("videoCapture", self._betterAPI_videoCapture_apikey) then
                        apikey_revoke("videoCapture", self._betterAPI_videoCapture_apikey)
                        self._betterAPI_videoCapture_apikey = nil
                    else
                        local sources = {"game"}
                        for i = 0, betterDLL.videoCapture_monitor_count() - 1 do
                            table.insert(sources, "monitor:" .. i)
                        end
                        for i = 0, betterDLL.videoCapture_camera_count() - 1 do
                            table.insert(sources, "camera:" .. i)
                        end
                        createPermissionGui(shapeClass, self, "video capture", "this will allow the shape to capture the REAL picture from your game/monitor/camera", function (_, source, toggles)
                            self._betterAPI_videoCapture_apikey = apikey_gen("videoCapture")
                            local keydata = apikey_getKeyData("videoCapture", self._betterAPI_videoCapture_apikey)
                            keydata.allowControl = toggles[1]
                            if source == "game" then
                                keydata.source = source
                            else
                                local iterator = source:gmatch("[^:]+")
                                keydata.source = iterator()
                                keydata.index = tonumber(iterator())
                                if keydata.source == "camera" then
                                    keydata.allowControl = false
                                end
                            end
                            self[callbackName](self, self._betterAPI_videoCapture_apikey)
                        end, sources, {--[["allow control"]]}, "you can use the \"usbmmidd_v2\" program to create virtual monitors")
                    end
                end
            end

            function shapeClass:client_canInteract()
                if apikey_check("videoCapture", self._betterAPI_videoCapture_apikey) then
                    sm.gui.setInteractionText("", "Press <p textShadow='false' bg='gui_keybinds_bg_orange' spacing='9' color='#65430B'>" .. sm.gui.getKeyBinding("Use") .. "</p> to stop capturing", "")
                    sm.gui.setInteractionText("", "", "")
                else
                    sm.gui.setInteractionText("", "Press <p textShadow='false' bg='gui_keybinds_bg_orange' spacing='9' color='#65430B'>" .. sm.gui.getKeyBinding("Use") .. "</p> to start capturing", "")
                    sm.gui.setInteractionText("", "", "")
                end
                return true
            end
        end,
        isAvailable = function(apikey)
            return apikey_check("videoCapture", apikey)
        end,
        cancel = function(apikey)
            apikey_revoke("videoCapture", apikey)
        end,
        getSize = function(apikey)
            apikey_checkErr("videoCapture", apikey)
            local keydata = apikey_getKeyData("videoCapture", apikey)
            if keydata.source == "monitor" then
                return betterDLL.videoCapture_monitor_resolution(keydata.index)
            elseif keydata.source == "camera" then
                return betterDLL.videoCapture_camera_resolution(keydata.index)
            else
                return betterDLL.videoCapture_game_resolution()
            end
        end,
        capture = function(apikey, width, height, x, y, sizeX, sizeY)
            checkArg(2, width, "number")
            checkArg(3, height, "number")
            checkArg(4, x, "number")
            checkArg(5, y, "number")
            checkArg(6, sizeX, "number")
            checkArg(7, sizeY, "number")
            apikey_checkErr("videoCapture", apikey)

            local rwidth, rheight = better.videoCapture.getSize(apikey)
            local mulX, mulY = rwidth / width, rheight / height
            local rx, ry, rsizeX, rsizeY = round(x * mulX), round(y * mulY), round(sizeX * mulX), round(sizeY * mulY)

            local keydata = apikey_getKeyData("videoCapture", apikey)
            if keydata.source == "monitor" then
                betterDLL.videoCapture_monitor(rx, ry, rsizeX, rsizeY, sizeX, sizeY, keydata.index)
            elseif keydata.source == "camera" then
                betterDLL.videoCapture_camera(rx, ry, rsizeX, rsizeY, sizeX, sizeY, keydata.index)
            else
                betterDLL.videoCapture_game(rx, ry, rsizeX, rsizeY, sizeX, sizeY)
            end

            local image = {}
            local size = sizeX * sizeY
            for i = 0, size - 1 do
                image[i+1] = betterDLL.videoCapture_get(i)
            end
            
            betterDLL.videoCapture_free()
            return image
        end,
        isControlAvailable = function(apikey)
            apikey_checkErr("videoCapture", apikey)
            local keydata = apikey_getKeyData("videoCapture", apikey)
            return not not keydata.allowControl
        end,
        touch = function(apikey, width, height, x, y, action, button)
            checkArg(2, width, "number")
            checkArg(3, height, "number")
            checkArg(4, x, "number")
            checkArg(5, y, "number")
            checkArg(6, action, "string")
            checkArg(7, button, "string", "number")
            apikey_checkErr("videoCapture", apikey)
            local keydata = apikey_getKeyData("videoCapture", apikey)
            if not keydata.allowControl then
                error("the user did not give permission to control", 2)
            elseif keydata.source == "camera" then
                error("there is no control API for the camera", 2)
            end

            if action == "pressed" or action == "press" or action == "touch" then
                action = 1
            elseif action == "drag" or action == "move" or action == "swipe" then
                action = 2
            elseif action == "released" or action == "drop" or action == "release" then
                action = 0
            else
                error("invalid action", 2)
            end

            if button == "left" or button == 1 then
                button = 1
            elseif button == "right" or button == 2 then
                button = 2
            else
                error("invalid button", 2)
            end

            local target = -1
            if keydata.source == "monitor" then
                target = keydata.index
            end

            local rwidth, rheight = better.videoCapture.getSize(apikey)
            local mulX, mulY = rwidth / width, rheight / height
            local rx, ry = round(x * mulX), round(y * mulY)
            betterDLL.videoCapture_touch(rx, ry, action, button, target)
        end
    },

    tts = {
        textToSpeech = function(text)
            checkArg(1, text, "string")
            modCheck("tts")

            if not ttsCache then
                local cacheDataPath = betterCacheLocalPath .. "/tts/cacheData.json"
                if betterDLL.filesystem_exists(cacheDataPath) then
                    ttsCache = json_parseJsonString(rawReadFile(cacheDataPath))
                end
            end

            if ttsCache and ttsCache[text] then
                return createAudio(betterCacheGlobalPath .. "/tts/" .. ttsCache[text], AUDIO_TYPE_FILE)
            end

            ttsCache = nil

            local path = betterTempGlobalPath .. "/tts/tts_" .. randomName() .. ".mp3"
            python.async("tts.py", betterDLL.base64_encode(text), path)
            local audioObject = createAudio(path, AUDIO_TYPE_FILE, 20, true, true)
            local audioScript = findAudioScript(audioObject)
            audioScript.fork = function()
                if not ttsCache then
                    local cacheDataPath = betterCacheLocalPath .. "/tts/cacheData.json"
                    if betterDLL.filesystem_exists(cacheDataPath) then
                        ttsCache = json_parseJsonString(rawReadFile(cacheDataPath))
                    end
                end
    
                if ttsCache and ttsCache[text] then
                    return createAudio(betterCacheGlobalPath .. "/tts/" .. ttsCache[text], AUDIO_TYPE_FILE)
                end

                local forkAudioObject = createAudio(path, AUDIO_TYPE_FILE, 20, true, true)
                local forkAudioScript = findAudioScript(forkAudioObject)
                forkAudioScript.ownerCounter = audioScript.ownerCounter
                forkAudioScript.ownerCounter.ownerCounter = forkAudioScript.ownerCounter.ownerCounter + 1
                return forkAudioObject
            end
            return audioObject
        end
    },

    extension = {
        isLoaded = function(name)
            modCheck()
            
            local enabledListPath = workingDirectory .. "\\MgrBetterExtensions\\extensions.json"
            local downloadedListPath = workingDirectory .. "\\MgrBetterExtensions\\downloadedExtensions.json"

            if betterDLL.filesystem_exists(enabledListPath) and betterDLL.filesystem_exists(downloadedListPath) then
                local downloadedList = json_parseJsonString(rawReadFile(downloadedListPath))

                local isDownloaded = false --verifies that the extension was downloaded from the repository
                for _, item in ipairs(downloadedList) do
                    if item.name == name then
                        isDownloaded = true
                        break
                    end
                end

                if isDownloaded then
                    local enabledList = json_parseJsonString(rawReadFile(enabledListPath))
                    for _, item in ipairs(enabledList) do
                        if hideExtension(item) == name then
                            return true
                        end
                    end
                end
            end

            return false
        end,
        require = function(name)
            modCheck()
            if better.extension.isLoaded(name) then
                return true
            end

            --i just wanted to make sure there was no injection
            if name:find("%'") or name:find("%\"") or name:find("%|") or name:find("%&") or name:find("%\\") or name:find("%/") then
                error("bad extension name")
            end

            asyncExecute("betterAPI", "betterAPI_shell.exe", "enable", name)
            return false
        end
    }
}

if not disableCoroutineFix then
    better.coroutine = { --for strange reasons, calling the game API methods inside coroutine calls bugsplat. this coroutine implementation is recognized to work around this
        fixed = true, --tells SComputers that it is not necessary to prevent the use of API methods from coroutine

        create = function(...)
            modCheck("coroutine")
            return coroutine.create(...)
        end,
        status = function(...)
            modCheck("coroutine")
            return coroutine.status(...)
        end,
        running = function(...)
            modCheck("coroutine")
            return coroutine.running(...)
        end,

        resume = function(co, ...)
            checkArg(1, co, "thread")
            modCheck("coroutine")
            local args = {...}
            while true do
                local result = {coroutine.resume(co, args and unpack(args, 1, holeLen(args)))}
                args = nil
                if result[1] then
                    if coroutine.status(co) == "dead" then 
                        return true, unpack(result, 2, holeLen(result))
                    elseif result[2] ~= nil then
                        if coroutine.running() then
                            args = {coroutine.yield(result[2])}
                        else
                            args = {{pcall(result[2][1], unpack(result[2][2]))}}
                        end
                    else
                        return true, unpack(result, 3, holeLen(result))
                    end
                else
                    return false, result[2]
                end
            end
        end,
        wrap = function(f)
            modCheck("coroutine")
            local co = coroutine.create(f)
            return function(...)
                local result = {better.coroutine.resume(co, ...)}
                if result[1] then
                    return unpack(result, 2, holeLen(result))
                else
                    error(result[2], 0)
                end
            end
        end,
        yield = function(...)
            modCheck("coroutine")
            return coroutine.yield(nil, ...)
        end
    }
else
    better.coroutine = better.nativeCoroutine
end

--------------------------------------------------- api hook

do
    local function upcall(func, ...)
        local result = coroutine.yield({func, {...}})
        if result[1] then
            return unpack(result, 2, holeLen(result))
        else
            error(result[2], 3)
        end
    end

    local metaFilled = setmetatable({}, {__mode = "k"})
    local hookedFunctions = setmetatable({}, {__mode = "k"})
    local whook = "withoutHook_"

    local userdataNames = {
        ["userdata"] = true,
        ["AiState"] = true,
        ["AreaTrigger"] = true,
        ["BlueprintVisualization"] = true,
        ["Body"] = true,
        ["BuilderGuide"] = true,
        ["Character"] = true,
        ["Color"] = true,
        ["Container"] = true,
        ["CullSphereGroup"] = true,
        ["Effect"] = true,
        ["GuiInterface"] = true,
        ["Harvestable"] = true,
        ["Interactable"] = true,
        ["Joint"] = true,
        ["Lift"] = true,
        ["LoadCellHandle"] = true,
        ["Network"] = true,
        ["PathNode"] = true,
        ["Player"] = true,
        ["Portal"] = true,
        ["Quat"] = true,
        ["RaycastResult"] = true,
        ["ScriptableObject"] = true,
        ["Shape"] = true,
        ["Storage"] = true,
        ["Tool"] = true,
        ["Unit"] = true,
        ["Uuid"] = true,
        ["Vec3"] = true,
        ["Widget"] = true,
        ["World"] = true
    }

    local metaKeys = {
        ["__index"] = true,
        ["__newindex"] = true,
        ["__call"] = true,
        ["__tostring"] = true,
        ["__concat"] = true,
        ["__len"] = true,
        ["__add"] = true,
        ["__sub"] = true,
        ["__mul"] = true,
        ["__div"] = true,
        ["__pow"] = true,
        ["__mod"] = true,
        ["__idiv"] = true,
        ["__eq"] = true,
        ["__lt"] = true,
        ["__le"] = true
    }

    local function hookObject(object, recursionTableInfo)
        recursionTableInfo = recursionTableInfo or {}

        local t = type(object)
        if userdataNames[t] then
            local metatable = getmetatable(object)
            if metatable and not metaFilled[metatable] then
                for metaKey in pairs(metaKeys) do
                    local old_func = metatable[metaKey]
                    if old_func then
                        local new_func
                        new_func = function (...)
                            if coroutine_running() then
                                return upcall(new_func, ...)
                            end

                            --local ret = {spcall(old_func, ...)}
                            local ret = {old_func(...)}
                            local retLen = holeLen(ret)
                            for i = 1, retLen do
                                ret[i] = hookObject(ret[i], recursionTableInfo)
                            end
                            return unpack(ret, 1, retLen)
                        end
                        metatable[metaKey] = new_func
                        metatable[whook .. metaKey] = old_func
                    end
                end

                --[[
                function metatable:__tostring()
                    if coroutine.running() then
                        return upcall(metatable.__tostring, self)
                    end

                    return tostring(self)
                end
                ]]

                metaFilled[metatable] = true
            end
        elseif t == "function" then
            if not hookedFunctions[object] then
                hookedFunctions[object] = function(...)
                    if coroutine.running() then
                        return upcall(object, ...)
                    end

                    --local ret = {spcall(object, ...)}
                    local ret = {object(...)}
                    local retLen = holeLen(ret)
                    for i = 1, retLen do
                        ret[i] = hookObject(ret[i], recursionTableInfo)
                    end
                    return unpack(ret, 1, retLen)
                end
            end

            return hookedFunctions[object]
        elseif t == "table" then
            if not recursionTableInfo[object] then
                recursionTableInfo[object] = true
                for k, v in pairs(object) do
                    object[k] = hookObject(v, recursionTableInfo)
                end
            end
        end

        return object
    end

    local hookedApis = setmetatable({}, {__mode = "k"})

    local function hookApi(tbl)
        if disableCoroutineFix then
            return
        end
        
        if hookedApis[tbl] then
            return
        end
        hookedApis[tbl] = true

        for k, v in pairs(tbl) do
            local t = type(v)
            if t == "table" then
                hookApi(v)
            elseif type(k) ~= "string" or k:sub(1, #whook) ~= whook then
                local nv = hookObject(v)
                tbl[k] = nv
                if nv ~= v then
                    tbl[whook .. k] = v
                end
            end
        end
    end

    local sm_exists = sm.exists
    function unsafe_env.sm.exists(obj)
        better.tick()
        return sm_exists(obj)
    end

    hookApi(sm)

    function unsafe_env.class(super)

        local klass = {}

        -- Copy members from super.
        if super then
            for k,v in pairs(super) do
                klass[k] = v
            end
        end

        local meta = {}

        -- Emulate constructor syntax.
        -- Triggers when a value is called like a function.
        meta.__call = function(self, ...)
            local instance = setmetatable({}, self)

            return instance
        end

        -- Emulate classes using prototyping.
        setmetatable(klass, meta)
        klass.__index = function(self, key)
            if key == "server_onCreate" or key == "client_onCreate" then
                local userfunc = rawget(klass, key)
                if userfunc then
                    return function (self, ...)
                        hookApi(self)
                        return userfunc(self, ...)
                    end
                end
            end
            
            return klass[key]
        end

        return klass

    end
end

--------------------------------------------------- update check

do
    betterTitle("update check")

    if _betterAPI_forceUpdate then
        forceUpdate = true
    end

    local workshopVersion = rawReadFile(selfWorkshopContentFolder .. versionFileName)
    if forceUpdate or (currentVersion and workshopVersion and currentVersion ~= workshopVersion) then
        print("start of automatic betterAPI update. force: ", forceUpdate)
        print("version: ", currentVersion, ">", workshopVersion)
        local from, to = fpathWithoutCheck(selfWorkshopContentFolder), "."
        print("copy", from, ">", to)
        python.async("betterUpdate.py", from, to, "ScrapMechanic.exe -last_save", workshopVersion)
        os.exit()
    else
        print("there are no updates")
        print("currentVersion", currentVersion)
        print("workshopVersion", workshopVersion)
    end
end

--------------------------------------------------- chat commands

do
    local added = false
    local oldBindCommand = sm.game.bindChatCommand
    local function bindCommandHook(command, params, callback, help)
        oldBindCommand(command, params, callback, help)
        if not added then
            oldBindCommand("/revoke", {}, "cl_onChatCommand", "revokes all permissions that you have given to mods via betterAPI")
            oldBindCommand("/better", {}, "cl_onChatCommand", "opens the \"betterAPI setup\" program")

            added = true
        end
    end
    sm.game.bindChatCommand = bindCommandHook

    local oldWorldEvent = sm.event.sendToWorld
    local function worldEventHook(world, callback, params)
        if params then
            if params[1] == "/revoke" then
                apikey_revokeAll()
                return
            elseif params[1] == "/better" then
                asyncExecute("betterAPI", "betterAPI_shell.exe")
            end
        end

        oldWorldEvent(world, callback, params)
    end
    sm.event.sendToWorld = worldEventHook
end

--------------------------------------------------- loading extensions

asyncExecute("betterAPI", "betterAPI_shell.exe", "init")

do
    betterTitle("loading extensions")

    local function loadLuaExtension(path, ...)
        print("loadLuaExtension...", "  ("  .. path .. ")")

        local func, err = loadfile(path)
        if func then
            print("loadLuaExtension result: ", xpcall(func, debug.traceback, better, ...))
        else
            print("loadLuaExtension err: ", err)
        end
    end

    local function loadDllExtension(path)
        print("loadDllExtension...", "  ("  .. path .. ")")
        print("loadDllExtension result: ", betterDLL.loadDLL(path))
    end

    local loadExtension

    local function installExtension(path, realtimeLoad)
        print("installExtension...", "  ("  .. path .. ")")
        local folder = unpackedExtensionsLocalPath .. "/" .. getPathName(path)
        local checksumPath = folder .. "/checksum"
        local checksum = betterDLL.sha256_file_text(path)
        if not betterDLL.filesystem_exists(checksumPath) or rawReadFile(checksumPath) ~= checksum then
            print("the beginning of unpacking")
            recreateDirectory(folder)
            os.execute("unzip -o -q " .. cmdEscapeWithoutCheck(path) .. " -d " .. cmdEscapeWithoutCheck(folder))
            rawWriteFile(checksumPath, checksum)
        else
            print("no update found, installation canceled")
        end

        if realtimeLoad then
            loadExtension(folder)
        end
    end

    local extensionLoaded = {}

    function loadExtension(path, realtimeLoad)
        if extensionLoaded[path] then
            return
        end
        extensionLoaded[path] = true

        print("loadExtension...", "  ("  .. path .. ")")
        
        if betterDLL.filesystem_isDir(path) then
            addPackageFolder(path)
            loadLuaExtension(path .. "/extension.lua", workingDirectory .. "\\" .. path .. "\\")
            loadDllExtension(path .. "/extension.dll")
        else
            local ext = getPathExtension(path) or "empty"
            if ext == "lua" then
                loadLuaExtension(path)
            elseif ext == "dll" then
                loadDllExtension(path)
            elseif ext == "bext" then
                installExtension(path, realtimeLoad)
            else
                print("unknown extension format: " .. ext)
            end
        end
    end

    local function loadExtensionsFromFolder(folder)
        for _, extension in ipairs(rawList(folder) or {}) do
            loadExtension(folder .. "/" .. extension)
        end
    end

    local betterExtensionListDirectories = {
        "betterAPI", --loading the built-in betterAPI modules
        "MgrBetterExtensions" --directory for extensions installed via "betterAPI setup"
    }

    local betterExtensionListDirectories_dynamicload = {
        "MgrBetterExtensions" --directory for extensions installed via "betterAPI setup"
    }

    local betterExtensionDirectories = {
        "BetterExtensions" --directory for manually installed extensions
    }

    for _, extension in ipairs(rawList(unpackedExtensionsLocalPath) or {}) do
        local extensionPath = unpackedExtensionsLocalPath .. "/" .. extension
        local findedSource = false
        local findingExtension = extension .. ".bext"
        for _, folder in ipairs(betterExtensionDirectories) do
            local localExtensionPath = folder .. "/" .. findingExtension
            if betterDLL.filesystem_exists(localExtensionPath) then
                findedSource = true
                break
            end
        end
        if not findedSource then
            for _, folder in ipairs(betterExtensionListDirectories) do
                local path = folder .. "/extensions.json"
                if betterDLL.filesystem_exists(path) then
                    for _, lextension in ipairs(json_parseJsonString(rawReadFile(path))) do
                        if findingExtension == lextension then
                            findedSource = true
                            break
                        end
                    end
                    if findedSource then
                        break
                    end
                end
            end
        end
        if not findedSource then
            print("removing the extension: " .. extensionPath)
            betterDLL.filesystem_remove(extensionPath)
        end
    end

    loadLuaExtension("betterDebug.lua")
    for _, folder in ipairs(betterExtensionListDirectories) do
        local path = folder .. "/extensions.json"
        if betterDLL.filesystem_exists(path) then
            for _, extension in ipairs(json_parseJsonString(rawReadFile(path))) do
                loadExtension(folder .. "/" .. extension)
            end
        end
    end
    for _, folder in ipairs(betterExtensionDirectories) do
        loadExtensionsFromFolder(folder)
    end
    loadExtensionsFromFolder(unpackedExtensionsLocalPath)
    loadLuaExtension("betterExtension.lua")

    function extensionDynamicload()
        for _, folder in ipairs(betterExtensionListDirectories_dynamicload) do
            local path = folder .. "/extensions.json"
            if betterDLL.filesystem_exists(path) then
                for _, extension in ipairs(json_parseJsonString(rawReadFile(path))) do
                    loadExtension(folder .. "/" .. extension, true)
                end
            end
        end
    end
end

--------------------------------------------------- creating a user interface for interacting with betterAPI

betterShadow = tableProtect(better)

unsafe_env.better = betterShadow
unsafe_env.setmetatable = betterShadow.setmetatable
unsafe_env.getmetatable = betterShadow.getmetatable