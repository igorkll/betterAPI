# example of an extension for betterAPI
this is an example of an extension for betterAPI  
the extension may contain an extension.lua file. It will be loaded when the extension is loaded and will receive as arguments the better table available for modification and the path to the extension folder.
the extension may contain a file extension.dll When the extension is loaded, it will be injected into the game process.  
the extension can also be packaged in a "bext" zip archive for easy transfer.  
for a more detailed guide on creating extensions for betterAPI, refer to the betterAPI documentation: https://igorkll.github.io/betterAPI/index.html