local better, directory = ...
--the better table is the betterAPI. you can use this table by extending it
--directory is the path to the extension folder. it can be used, for example, to load the DLL files next to the file
--the directory already contains "\\" at the end of the path name

print("example betterAPI extension")
print("directory: " .. directory)

local mods = {
    {
        localId = "ab3d7b03-ec14-4827-91b3-bc0aaa28733e",
        name = "scripts tests",
        apis = {"test"}
    }     
}

better.test = {
    test1 = function() --the feature is available to all mods in the game.
        print("function 1")
    end,
    test2 = function() --the feature is only available for mods from the betterAPI mods list and only for those with access to the audio API
        bext.modCheck("audio")
        print("function 2")
    end,
    test3 = function() --the feature is available for mods from the standard betterAPI mod list and for mods from the local extension list
        bext.modCheckEx(mods)
        print("function 3")
    end,
    test4 = function() --the feature is available for mods from the betterAPI list and from the local list, but only for those who have access to the "test" api
        bext.modCheckEx(mods, "test")
        print("function 4")
    end,
    test5 = function() --the feature is only available for mods from the local mods list
        bext.modCheckCEx(mods)
        print("function 5")
    end,
    test6 = function() --this feature is only available for mods from the local list of mods and only for those who have access to the "test" api
        bext.modCheckCEx(mods, "test")
        print("function 6")
    end,
    test7 = function() --this feature is only available by a mods from the local list of mods and only to those who have access to the api test and test2
        bext.modCheckCEx(mods, "test", "test2")
        print("function 7")
    end
}

--you can inject a DLL into the game. if you name your file extension.dll, it will be injected automatically when the extension is loaded.
--please note that all DLL files will be unloaded after exiting the world.
--bext.loadDLL(directory .. "SM-BetterPaintTool.dll") 

bext.registerHandler_exit(function ()
    print("example betterAPI extension - exit")
end)

--[[
bext.registerHandler_tick(function ()
    print("example betterAPI extension - tick")
end)
]]