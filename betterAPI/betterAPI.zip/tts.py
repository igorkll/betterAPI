import pyttsx3
import sys
import re
import uuid
import shutil
import base64
import json
import os

text = base64.b64decode(sys.argv[2]).decode('utf-8')
path = sys.argv[3]

cachePath = 'BetterCache/tts/cacheData.json'
busyFlagPath = 'BetterTemp/tts/cacheData_busy'

# --------------------------------------- generate new tts sample

fileName = f"tts_{str(uuid.uuid4())}.mp3"
filePath = "BetterCache/tts/" + fileName

engine = pyttsx3.init()
voices = engine.getProperty('voices')

def has_cyrillic(text):
    return bool(re.search('[а-яА-Я]', text))

if has_cyrillic(text):
    textLang = "Russian"
else:
    textLang = "English"

for _, _voice in enumerate(voices):
    voice = _voice
    if textLang in voice.languages or textLang in voice.name:
        break

engine.setProperty('voice', voice)
engine.setProperty('volume', 1.0)
engine.save_to_file(text, filePath)
engine.runAndWait()

# --------------------------------------- save info to cache

with open(busyFlagPath, 'w', encoding='utf-8') as file:
    pass

if os.path.isfile(cachePath):
    with open(cachePath, 'r', encoding='utf-8') as file:
        cacheData = json.load(file)
else:
    cacheData = {}

cacheData[text] = fileName

with open(cachePath, 'w', encoding='utf-8') as file:
    json.dump(cacheData, file, ensure_ascii=False, indent=4)

os.remove(busyFlagPath)

# --------------------------------------- copy to user path

shutil.copy2(filePath, path)