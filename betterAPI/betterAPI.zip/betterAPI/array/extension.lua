local better = ...
local ffi = require("ffi")

local function checkArrayLen(len)
    if len <= 0 then
        error("invalid array length", 3)
    end
end

better.array = {
    create_uint8 = function (len)
        bext.checkArg(1, len, "number")
        bext.modCheck("array")
        checkArrayLen(len)
        return ffi.new("uint8_t[?]", len)
    end,
    create_uint16 = function (len)
        bext.checkArg(1, len, "number")
        bext.modCheck("array")
        checkArrayLen(len)
        return ffi.new("uint16_t[?]", len)
    end,
    create_uint32 = function (len)
        bext.checkArg(1, len, "number")
        bext.modCheck("array")
        checkArrayLen(len)
        return ffi.new("uint32_t[?]", len)
    end,
    create_uint64 = function (len)
        bext.checkArg(1, len, "number")
        bext.modCheck("array")
        checkArrayLen(len)
        return ffi.new("uint64_t[?]", len)
    end,

    create_int8 = function (len)
        bext.checkArg(1, len, "number")
        bext.modCheck("array")
        checkArrayLen(len)
        return ffi.new("int8_t[?]", len)
    end,
    create_int16 = function (len)
        bext.checkArg(1, len, "number")
        bext.modCheck("array")
        checkArrayLen(len)
        return ffi.new("int16_t[?]", len)
    end,
    create_int32 = function (len)
        bext.checkArg(1, len, "number")
        bext.modCheck("array")
        checkArrayLen(len)
        return ffi.new("int32_t[?]", len)
    end,
    create_int64 = function (len)
        bext.checkArg(1, len, "number")
        bext.modCheck("array")
        checkArrayLen(len)
        return ffi.new("int64_t[?]", len)
    end,

    create_double = function (len)
        bext.checkArg(1, len, "number")
        bext.modCheck("array")
        checkArrayLen(len)
        return ffi.new("double[?]", len)
    end,
    create_float = function (len)
        bext.checkArg(1, len, "number")
        bext.modCheck("array")
        checkArrayLen(len)
        return ffi.new("float[?]", len)
    end
}