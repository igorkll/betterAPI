if not unsafe_env or not unsafe_env.sm.player or _betterInit then
    return
end
_betterInit = true

local function loaderPrint(str)
    print("BETTER-API: " .. str)
end

loaderPrint("|-----------------------------------|")
loaderPrint("|             BETTER API            |")
loaderPrint("|              LOADER 4             |")
loaderPrint("|-----------------------------------|")

if _set_better then
    loaderPrint("calling _set_better...")
    _set_better()
    loaderPrint("_set_better called")
else
    loaderPrint("_set_better not found")
end
loaderPrint("env-table: " .. tostring(unsafe_env))

local code, err = loadfile("betterAPI.lua")
local success = not not code
if code then
    success, err = xpcall(code, debug.traceback)
end

if success then
    loaderPrint("successfully loaded")
else
    loaderPrint("ERROR: " .. tostring(err))
    loaderPrint("calling _release_better...")
    _release_better()
    loaderPrint("_release_better called")
    os.execute("echo " .. string.char(7))
end